"""
Quick fix to update user email for password reset testing
Run this script to update the n3thunt3r user email
"""

# For development, temporarily change email backend to console
# Add this to your settings.py for testing:

# EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# This will show emails in the terminal instead of sending real emails

print("""
🔧 QUICK FIXES FOR EMAIL ISSUE:

1. TEMPORARY SOLUTION (for testing):
   Add this line to ToDoList/settings.py at the bottom:
   
   EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
   
   This will show emails in the terminal instead of sending real ones.

2. UPDATE USER EMAIL:
   Go to http://127.0.0.1:8000/admin/ and:
   - Login as admin
   - Go to Login > Logins 
   - Edit the 'n3thunt3r' user
   - Change email from 'nethunterghana@gmail.com' to 'benedictamankwa18@gmail.com'
   - Save

3. CREATE NEW USER:
   Go to http://127.0.0.1:8000/register/ and create a new account with:
   - Username: benedict
   - Email: benedictamankwa18@gmail.com
   - Password: (your choice)

4. REAL EMAIL SETUP (for production):
   Create a .env file with:
   EMAIL_HOST_USER=your-gmail@gmail.com
   EMAIL_HOST_PASSWORD=your-app-password
   
   Note: You need a Gmail App Password, not your regular password.
""")
