#!/usr/bin/env python
"""
Test Django template rendering for password reset emails
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from django.template.loader import render_to_string
from django.contrib.sites.shortcuts import get_current_site
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.test import RequestFactory
from django.core.mail import EmailMultiAlternatives
from django.conf import settings
from Login.models import Login

def test_template_rendering():
    """Test if the email template renders properly with Django template engine"""
    print("🧪 TESTING DJANGO TEMPLATE RENDERING")
    print("=" * 60)
    
    # Create a mock request
    factory = RequestFactory()
    request = factory.get('/')
    request.META['HTTP_HOST'] = '127.0.0.1:8000'
    
    # Get a test user
    user = Login.objects.filter(email__isnull=False).first()
    if not user:
        print("❌ No user with email found for testing")
        return False
        
    print(f"👤 Testing with user: {user.username} ({user.email})")
    
    # Generate password reset context
    domain = '127.0.0.1:8000'
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = default_token_generator.make_token(user)
    
    context = {
        'user': user,
        'protocol': 'http',
        'domain': domain,
        'uid': uid,
        'token': token,
    }
    
    print(f"\n📧 Template Context:")
    print(f"   Protocol: {context['protocol']}")
    print(f"   Domain: {context['domain']}")
    print(f"   UID: {context['uid']}")
    print(f"   Token: {context['token'][:20]}...")
    
    try:
        # Test template rendering
        print(f"\n🔧 Rendering email template...")
        html_content = render_to_string('password_reset_email.html', context)
        
        # Check if template variables were rendered
        if '{% url' in html_content or '{{ protocol }}' in html_content:
            print("❌ Template tags not rendered - found raw Django syntax")
            print("💡 This means the template is not being processed correctly")
            return False
        else:
            print("✅ Template rendered successfully - no raw Django syntax found")
            
        # Check if the URL was properly constructed
        expected_url = f"http://127.0.0.1:8000/password-reset-confirm/{uid}/{token}/"
        if expected_url in html_content:
            print(f"✅ Password reset URL properly constructed")
            print(f"🔗 URL: {expected_url}")
        else:
            print("⚠️ Password reset URL may not be correctly constructed")
            
        # Show a preview of the rendered content
        print(f"\n📄 Template Preview (first 200 chars):")
        print(f"   {html_content[:200]}...")
        
        return True
        
    except Exception as e:
        print(f"❌ Template rendering failed: {e}")
        return False

def send_test_email_with_proper_rendering():
    """Send a test email using proper Django template rendering"""
    print(f"\n📨 SENDING TEST EMAIL WITH PROPER RENDERING")
    print("=" * 60)
    
    # Get test user
    user = Login.objects.filter(email='benedictamankwa18@gmail.com').first()
    if not user:
        print("❌ User with email benedictamankwa18@gmail.com not found")
        return False
    
    print(f"👤 Sending to: {user.username} ({user.email})")
    
    # Create context
    domain = '127.0.0.1:8000'
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = default_token_generator.make_token(user)
    
    context = {
        'user': user,
        'protocol': 'http',
        'domain': domain,
        'uid': uid,
        'token': token,
    }
    
    try:
        # Render templates
        subject = render_to_string('password_reset_subject.txt', context).strip()
        html_message = render_to_string('password_reset_email.html', context)
        
        # Create and send email
        email = EmailMultiAlternatives(
            subject=subject,
            body='Please use an HTML-compatible email client to view this message.',
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[user.email],
        )
        email.attach_alternative(html_message, "text/html")
        email.send()
        
        print(f"✅ Email sent successfully!")
        print(f"📧 Subject: {subject}")
        print(f"📬 Sent to: {user.email}")
        print(f"🔗 Reset URL: http://127.0.0.1:8000/password-reset-confirm/{uid}/{token}/")
        
        return True
        
    except Exception as e:
        print(f"❌ Email sending failed: {e}")
        return False

if __name__ == "__main__":
    print("🚀 DJANGO EMAIL TEMPLATE RENDERING TEST")
    print("=" * 70)
    
    # Test 1: Template rendering
    template_ok = test_template_rendering()
    
    if template_ok:
        # Test 2: Send actual email
        email_ok = send_test_email_with_proper_rendering()
        
        if email_ok:
            print(f"\n🎉 EMAIL TEMPLATE RENDERING IS WORKING!")
            print("=" * 50)
            print("✅ Django templates are rendering correctly")
            print("✅ Password reset URLs are being generated")
            print("✅ Email is being sent with proper HTML")
            print("📱 Check your email inbox for the test email")
        else:
            print(f"\n🚨 EMAIL SENDING FAILED")
            print("Template rendering works but email delivery failed")
    else:
        print(f"\n🚨 TEMPLATE RENDERING FAILED")
        print("Need to fix template rendering before testing email sending")
    
    print(f"\n💡 Next steps:")
    print(f"1. Check email inbox (including spam folder)")
    print(f"2. Try password reset from web interface") 
    print(f"3. Verify reset link works when clicked")
