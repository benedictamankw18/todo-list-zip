#!/usr/bin/env python3
"""
PythonAnywhere Notification Script
Run this as a scheduled task to send automatic notifications
"""

import os
import sys
import django
import logging
from datetime import datetime

# Add project path
project_path = '/home/yourusername/todolist'  # Update with your username
if project_path not in sys.path:
    sys.path.insert(0, project_path)

# Load environment variables
from dotenv import load_dotenv
load_dotenv('/home/yourusername/.env')  # Update with your username

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

# Configure logging for PythonAnywhere
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/yourusername/notification_logs.log'),  # Update with your username
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

def main():
    """Main function to run notifications"""
    try:
        logger.info("=== Starting PythonAnywhere Notification Check ===")
        
        # Import after Django setup
        from Dashboard.notification_service import NotificationService
        
        # Create service and run notifications
        service = NotificationService()
        service.check_and_send_notifications()
        
        logger.info("✅ Notification check completed successfully")
        
    except Exception as e:
        logger.error(f"❌ Error in notification check: {str(e)}")
        raise

if __name__ == "__main__":
    main()
