"""
Database relationship checker for notification preferences
Run this after fixing the Django environment to verify the relationships
"""

import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Dashboard.models import NotificationPreference
from Login.models import Login

def check_notification_relationships():
    """Check if notification preferences are properly linked to Login users"""
    print("🔍 Checking Notification Preference Relationships")
    print("=" * 55)
    
    # Get all Login users
    users = Login.objects.all()
    print(f"📊 Total Login users: {users.count()}")
    
    # Check notification preferences
    prefs = NotificationPreference.objects.all()
    print(f"📊 Total Notification Preferences: {prefs.count()}")
    
    print("\n🔗 User -> Notification Preference Mapping:")
    print("-" * 50)
    
    for user in users:
        try:
            pref = NotificationPreference.objects.get(user=user)
            print(f"✅ {user.username} ({user.email}) -> Preference ID: {pref.id}")
            print(f"   📧 Email notifications: {pref.email_notifications}")
            print(f"   📱 WhatsApp notifications: {pref.whatsapp_notifications}")
            print(f"   📧 Notification email: {pref.notification_email}")
        except NotificationPreference.DoesNotExist:
            print(f"❌ {user.username} ({user.email}) -> No preferences found")
        except Exception as e:
            print(f"🚨 {user.username} ({user.email}) -> Error: {e}")
        print()
    
    # Check for orphaned preferences
    print("🧹 Checking for orphaned notification preferences:")
    print("-" * 50)
    
    orphaned = 0
    for pref in prefs:
        try:
            user = pref.user
            if not user:
                print(f"❌ Preference ID {pref.id} has no user")
                orphaned += 1
        except Exception as e:
            print(f"🚨 Preference ID {pref.id} -> Error: {e}")
            orphaned += 1
    
    if orphaned == 0:
        print("✅ No orphaned preferences found")
    else:
        print(f"⚠️ Found {orphaned} orphaned preferences")
    
    print("\n" + "=" * 55)
    print("💡 If you see issues:")
    print("1. Run: python manage.py makemigrations Dashboard")
    print("2. Run: python manage.py migrate")
    print("3. Re-run this script to verify")

def create_missing_preferences():
    """Create notification preferences for users who don't have them"""
    print("\n🔧 Creating missing notification preferences...")
    
    users_without_prefs = []
    for user in Login.objects.all():
        if not hasattr(user, 'notification_preference'):
            users_without_prefs.append(user)
    
    if not users_without_prefs:
        print("✅ All users have notification preferences")
        return
    
    print(f"📝 Creating preferences for {len(users_without_prefs)} users:")
    
    for user in users_without_prefs:
        try:
            pref = NotificationPreference.objects.create(
                user=user,
                notification_email=user.email,
                email_notifications=True,
                whatsapp_notifications=True,
                task_due_notifications=True
            )
            print(f"✅ Created preferences for {user.username}")
        except Exception as e:
            print(f"❌ Failed to create preferences for {user.username}: {e}")

if __name__ == "__main__":
    try:
        check_notification_relationships()
        create_missing_preferences()
    except Exception as e:
        print(f"❌ Error running checks: {e}")
        print("Make sure Django is properly installed and configured")
