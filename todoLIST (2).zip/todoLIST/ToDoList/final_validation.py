#!/usr/bin/env python3
"""
Final validation script for WhatsApp integration
"""

import os
import sys
import django
import requests
from datetime import datetime

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login as User
from Dashboard.models import Social

def final_validation():
    """Final validation of WhatsApp integration"""
    
    print("🎯 FINAL VALIDATION - WhatsApp Integration")
    print("=" * 60)
    print(f"📅 Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    validation_results = {
        'database_test': False,
        'template_test': False,
        'server_test': False,
        'crud_test': False,
        'security_test': False
    }
    
    # Test 1: Database Integration
    print("\n🔍 Test 1: Database Integration")
    try:
        user = User.objects.filter(username='testuser').first()
        if user:
            # Clean up
            Social.objects.filter(user=user, name='WHATSAPP').delete()
            
            # Create WhatsApp account
            whatsapp = Social.objects.create(
                user=user,
                name='WHATSAPP',
                url='https://wa.me/1234567890',
                icon='fab fa-whatsapp'
            )
            
            if whatsapp.id:
                print("✅ Database integration: PASSED")
                validation_results['database_test'] = True
            else:
                print("❌ Database integration: FAILED")
        else:
            print("❌ Test user not found")
    except Exception as e:
        print(f"❌ Database integration: FAILED - {e}")
    
    # Test 2: Template Integration
    print("\n🔍 Test 2: Template Integration")
    try:
        template_path = 'Setting/templates/setting.html'
        if os.path.exists(template_path):
            with open(template_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'WHATSAPP' in content and 'fab fa-whatsapp' in content:
                print("✅ Template integration: PASSED")
                validation_results['template_test'] = True
            else:
                print("❌ Template integration: FAILED")
        else:
            print("❌ Template file not found")
    except Exception as e:
        print(f"❌ Template integration: FAILED - {e}")
    
    # Test 3: Server Response
    print("\n🔍 Test 3: Server Response")
    try:
        response = requests.get('http://127.0.0.1:8000/setting/', timeout=5)
        if response.status_code == 200:
            # Check if WhatsApp option is available in the response
            if 'WHATSAPP' in response.text and 'fab fa-whatsapp' in response.text:
                print("✅ Server response: PASSED")
                validation_results['server_test'] = True
            else:
                print("❌ Server response: FAILED - WhatsApp not found in response")
        else:
            print(f"❌ Server response: FAILED - Status: {response.status_code}")
    except Exception as e:
        print(f"❌ Server response: FAILED - {e}")
        # Server might be down, but that's okay for this test
    
    # Test 4: CRUD Operations
    print("\n🔍 Test 4: CRUD Operations")
    try:
        if user:
            # CREATE
            whatsapp = Social.objects.create(
                user=user,
                name='WHATSAPP_TEST',
                url='https://wa.me/1111111111',
                icon='fab fa-whatsapp'
            )
            
            # READ
            read_test = Social.objects.filter(id=whatsapp.id).first()
            
            # UPDATE
            whatsapp.url = 'https://wa.me/2222222222'
            whatsapp.save()
            
            # DELETE
            whatsapp_id = whatsapp.id
            whatsapp.delete()
            
            # Verify deletion
            deleted = Social.objects.filter(id=whatsapp_id).first()
            
            if read_test and not deleted:
                print("✅ CRUD operations: PASSED")
                validation_results['crud_test'] = True
            else:
                print("❌ CRUD operations: FAILED")
    except Exception as e:
        print(f"❌ CRUD operations: FAILED - {e}")
    
    # Test 5: Security & User Isolation
    print("\n🔍 Test 5: Security & User Isolation")
    try:
        # Create test users
        user1 = User.objects.filter(username='testuser').first()
        user2, created = User.objects.get_or_create(
            username='testuser2',
            defaults={'password': 'testpass123'}
        )
        
        if user1 and user2:
            # Clean up existing data
            Social.objects.filter(user__username__in=['testuser', 'testuser2']).delete()
            
            # Create social accounts for both users
            social1 = Social.objects.create(
                user=user1,
                name='WHATSAPP',
                url='https://wa.me/1111111111',
                icon='fab fa-whatsapp'
            )
            
            social2 = Social.objects.create(
                user=user2,
                name='WHATSAPP',
                url='https://wa.me/2222222222',
                icon='fab fa-whatsapp'
            )
            
            # Test isolation
            user1_socials = Social.objects.filter(user=user1, name='WHATSAPP').count()
            user2_socials = Social.objects.filter(user=user2, name='WHATSAPP').count()
            
            if user1_socials == 1 and user2_socials == 1:
                print("✅ Security & isolation: PASSED")
                validation_results['security_test'] = True
            else:
                print(f"❌ Security & isolation: FAILED - User1: {user1_socials}, User2: {user2_socials}")
        else:
            print("❌ Security & isolation: FAILED - Could not create test users")
            
        # Cleanup
        Social.objects.filter(user__username__in=['testuser', 'testuser2']).delete()
        if created:
            User.objects.filter(username='testuser2').delete()
            
    except Exception as e:
        print(f"❌ Security & isolation: FAILED - {e}")
    
    # Final Results
    print("\n" + "=" * 60)
    print("📊 FINAL VALIDATION RESULTS")
    print("=" * 60)
    
    passed_tests = sum(validation_results.values())
    total_tests = len(validation_results)
    
    for test_name, result in validation_results.items():
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{test_name.replace('_', ' ').title():<25} | {status}")
    
    print("=" * 60)
    print(f"Overall Score: {passed_tests}/{total_tests} ({passed_tests/total_tests*100:.1f}%)")
    
    if passed_tests == total_tests:
        print("🎉 ALL TESTS PASSED - WhatsApp integration is COMPLETE!")
        print("✅ WhatsApp is ready for production use")
        print("📱 Users can now add WhatsApp accounts from the Settings page")
        print("🔒 All security measures are in place")
    else:
        print("⚠️  Some tests failed - please review the issues above")
    
    print("\n🏁 Final validation complete!")

if __name__ == "__main__":
    final_validation()
