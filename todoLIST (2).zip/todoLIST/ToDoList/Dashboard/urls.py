from django.urls import path
from . import views
from . import views_statistics

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('add/', views.add_task, name='add_task'),
    path('update/<int:task_id>/', views.update_task, name='update_task'),
    path('delete/<int:task_id>/', views.delete_task, name='delete_task'),
    path('delete-selected/', views.delete_selected_tasks, name='delete_selected_tasks'),
    path('clear-all/', views.clear_all_tasks, name='clear_all_tasks'),
    path('clear-completed/', views.clear_completed_tasks, name='clear_completed_tasks'),
    path('export-tasks/', views.export_tasks, name='export_tasks'),
    path('settings/save/', views.save_settings, name='save_settings'),
    path('settings/get/', views.get_settings, name='get_settings'),

    # Statistics URLs
    path('statistics/', views_statistics.statistics_view, name='statistics'),
    path('statistics/api/tasks/', views_statistics.task_analytics_api, name='task_analytics_api'),
    path('statistics/api/notifications/', views_statistics.notification_analytics_api, name='notification_analytics_api'),
]