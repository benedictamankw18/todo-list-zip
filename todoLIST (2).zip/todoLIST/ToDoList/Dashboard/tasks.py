from celery import shared_task
from django.utils import timezone
from .notification_service import NotificationService
import logging

logger = logging.getLogger(__name__)

@shared_task
def send_task_notifications():
    """Celery task to check and send notifications"""
    try:
        notification_service = NotificationService()
        notification_service.check_and_send_notifications()
        logger.info(f"Notification check completed at {timezone.now()}")
        return "Notifications processed successfully"
    except Exception as e:
        logger.error(f"Error in notification task: {str(e)}")
        raise e

@shared_task  
def send_individual_notification(user_id, task_id, notification_type):
    """Send notification for a specific user and task"""
    try:
        from django.contrib.auth import get_user_model
        from TaskManager.models import Task
        
        User = get_user_model()
        user = User.objects.get(id=user_id)
        # Ensure the task belongs to the user
        task = Task.objects.get(id=task_id, owner=user.username)
        
        notification_service = NotificationService()
        results = notification_service.send_task_notification(user, task, notification_type)
        
        logger.info(f"Individual notification sent: User {user_id}, Task {task_id}, Type {notification_type}")
        return results
        
    except Exception as e:
        logger.error(f"Error sending individual notification: {str(e)}")
        raise e

@shared_task
def send_daily_summary():
    """Send daily summary to all users who have it enabled"""
    try:
        from django.contrib.auth import get_user_model
        from .models import NotificationPreference
        from TaskManager.models import Task
        
        User = get_user_model()
        
        # Get all users with daily summary enabled
        preferences = NotificationPreference.objects.filter(daily_summary=True)
        
        for pref in preferences:
            user = pref.user
            
            # Get user's tasks for today
            today = timezone.now().date()
            tasks_due_today = Task.objects.filter(
                owner=user.username,
                end=today,
                status='INCOMPLETE'
            )
            
            tasks_starting_today = Task.objects.filter(
                owner=user.username,
                start=today,
                status='INCOMPLETE'
            )
            
            if tasks_due_today.exists() or tasks_starting_today.exists():
                notification_service = NotificationService()
                # Create a summary message
                summary_message = f"Daily Summary for {today}:\n"
                
                if tasks_starting_today.exists():
                    summary_message += f"\nTasks Starting Today ({tasks_starting_today.count()}):\n"
                    for task in tasks_starting_today:
                        summary_message += f"• {task.task}\n"
                
                if tasks_due_today.exists():
                    summary_message += f"\nTasks Due Today ({tasks_due_today.count()}):\n" 
                    for task in tasks_due_today:
                        summary_message += f"• {task.task}\n"
                
                # Send via enabled channels
                if pref.email_notifications:
                    notification_service._send_summary_email(user, summary_message)
                if pref.sms_notifications:
                    notification_service._send_summary_sms(user, summary_message)
                if pref.whatsapp_notifications:
                    notification_service._send_summary_whatsapp(user, summary_message)
        
        logger.info(f"Daily summaries sent at {timezone.now()}")
        return "Daily summaries sent successfully"
        
    except Exception as e:
        logger.error(f"Error sending daily summaries: {str(e)}")
        raise e
