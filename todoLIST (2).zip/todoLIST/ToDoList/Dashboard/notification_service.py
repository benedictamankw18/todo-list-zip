import smtplib
import logging
import os
from datetime import datetime, timedelta
from django.conf import settings
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils import timezone
from .models import NotificationPreference, NotificationLog
from TaskManager.models import Task

# Optional imports with fallbacks
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    logging.warning("requests package not available. WhatsApp notifications will be disabled.")

try:
    from twilio.rest import Client as TwilioClient
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False
    logging.warning("twilio package not available. SMS notifications will be disabled.")

logger = logging.getLogger(__name__)

class NotificationService:
    """Service class to handle sending notifications via email, SMS, and WhatsApp"""
    
    def __init__(self):
        # Twilio configuration for SMS and WhatsApp
        self.twilio_sid = getattr(settings, 'TWILIO_ACCOUNT_SID', None)
        self.twilio_token = getattr(settings, 'TWILIO_AUTH_TOKEN', None)
        self.twilio_phone = getattr(settings, 'TWILIO_PHONE_NUMBER', None)
    
    def send_email_notification(self, user, task, notification_type):
        """Send email notification for task"""
        try:
            prefs = NotificationPreference.objects.get(user=user)
            if not prefs.email_notifications:
                return False
                
            email = prefs.notification_email or user.email
            if not email:
                return False
                
            subject = self._get_email_subject(task, notification_type)
            message = self._get_email_message(task, notification_type)
            
            send_mail(
                subject=subject,
                message=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[email],
                fail_silently=False,
            )
            
            self._log_notification(user, task.id, 'EMAIL', message, 'SENT')
            return True
            
        except Exception as e:
            logger.error(f"Failed to send email notification: {str(e)}")
            self._log_notification(user, task.id, 'EMAIL', str(e), 'FAILED', str(e))
            return False
    
    def send_sms_notification(self, user, task, notification_type):
        """Send SMS notification using Twilio"""
        try:
            if not TWILIO_AVAILABLE:
                logger.error("Twilio package not installed. Cannot send SMS.")
                return False
                
            prefs = NotificationPreference.objects.get(user=user)
            if not prefs.sms_notifications or not prefs.phone_number:
                return False
                
            if not all([self.twilio_sid, self.twilio_token, self.twilio_phone]):
                logger.error("Twilio credentials not configured")
                return False
                
            message = self._get_sms_message(task, notification_type)
            
            # Twilio API call
            client = TwilioClient(self.twilio_sid, self.twilio_token)
            
            message_obj = client.messages.create(
                body=message,
                from_=self.twilio_phone,
                to=prefs.phone_number
            )
            
            self._log_notification(user, task.id, 'SMS', message, 'SENT')
            return True
            
        except Exception as e:
            logger.error(f"Failed to send SMS notification: {str(e)}")
            self._log_notification(user, task.id, 'SMS', str(e), 'FAILED', str(e))
            return False
    
    def send_whatsapp_notification(self, user, task, notification_type):
        """Send WhatsApp notification via Twilio"""
        try:
            if not TWILIO_AVAILABLE:
                logger.error("Twilio package not installed. Cannot send WhatsApp messages.")
                return False
                
            prefs = NotificationPreference.objects.get(user=user)
            if not prefs.whatsapp_notifications or not prefs.phone_number:
                return False
                
            if not all([self.twilio_sid, self.twilio_token]):
                logger.error("Twilio credentials not configured for WhatsApp")
                return False
                
            # Get WhatsApp settings from environment
            whatsapp_from = os.getenv('WHATSAPP_FROM_NUMBER', 'whatsapp:+14155238886')
            content_sid = os.getenv('WHATSAPP_CONTENT_SID')
            
            # Format phone number for WhatsApp
            whatsapp_to = f"whatsapp:{prefs.phone_number}"
            if not prefs.phone_number.startswith('+'):
                whatsapp_to = f"whatsapp:+{prefs.phone_number}"
            
            # Twilio WhatsApp API call
            client = TwilioClient(self.twilio_sid, self.twilio_token)
            
            if content_sid:
                # Use content template if available
                date_str = task.end.strftime("%m/%d") if task.end else "soon"
                time_str = "5pm"  # Default time since Task model only has dates
                
                message_obj = client.messages.create(
                    to=whatsapp_to,
                    from_=whatsapp_from,
                    content_sid=content_sid,
                    content_variables=f'{{"1":"{date_str}","2":"{time_str}"}}'
                )
            else:
                # Use plain text message
                message = self._get_whatsapp_message(task, notification_type)
                message_obj = client.messages.create(
                    body=message,
                    to=whatsapp_to,
                    from_=whatsapp_from
                )
            
            self._log_notification(user, task.id, 'WHATSAPP', 
                                 f"WhatsApp sent via Twilio (SID: {message_obj.sid})", 'SENT')
            return True
                
        except Exception as e:
            logger.error(f"Failed to send WhatsApp notification: {str(e)}")
            self._log_notification(user, task.id, 'WHATSAPP', str(e), 'FAILED', str(e))
            return False
    
    def send_task_notification(self, user, task, notification_type):
        """Send notification via all enabled channels"""
        results = {}
        
        prefs, created = NotificationPreference.objects.get_or_create(user=user)
        
        # Check if this type of notification is enabled
        if notification_type == 'start' and not prefs.task_start_notifications:
            return results
        elif notification_type == 'due' and not prefs.task_due_notifications:
            return results
            
        # Send via all enabled channels
        if prefs.email_notifications:
            results['email'] = self.send_email_notification(user, task, notification_type)
            
        if prefs.sms_notifications:
            results['sms'] = self.send_sms_notification(user, task, notification_type)
            
        if prefs.whatsapp_notifications:
            results['whatsapp'] = self.send_whatsapp_notification(user, task, notification_type)
            
        return results
    
    def check_and_send_notifications(self):
        """Check for tasks that need notifications and send them"""
        now = timezone.now()
        
        # Get all tasks that haven't been completed
        tasks = Task.objects.filter(status='INCOMPLETE')
        
        for task in tasks:
            try:
                # Find the user (assuming task.owner is username)
                from django.contrib.auth import get_user_model
                User = get_user_model()
                user = User.objects.get(username=task.owner)
                prefs = NotificationPreference.objects.get(user=user)
                
                # Convert dates to datetime for comparison
                start_datetime = timezone.make_aware(
                    datetime.combine(task.start, datetime.min.time())
                )
                end_datetime = timezone.make_aware(
                    datetime.combine(task.end, datetime.min.time())
                )
                
                # Check if we should send start notification
                if prefs.task_start_notifications:
                    time_to_start = start_datetime - now
                    if timedelta(0) <= time_to_start <= timedelta(minutes=prefs.notification_timing_minutes):
                        # Check if we haven't already sent this notification today
                        if not self._notification_already_sent(user, task.id, 'start'):
                            self.send_task_notification(user, task, 'start')
                
                # Check if we should send due notification
                if prefs.task_due_notifications:
                    time_to_due = end_datetime - now
                    if timedelta(0) <= time_to_due <= timedelta(minutes=prefs.notification_timing_minutes):
                        # Check if we haven't already sent this notification today
                        if not self._notification_already_sent(user, task.id, 'due'):
                            self.send_task_notification(user, task, 'due')
                            
            except Exception as e:
                logger.error(f"Error processing notifications for task {task.id}: {str(e)}")
                continue
    
    def _notification_already_sent(self, user, task_id, notification_type):
        """Check if we've already sent this notification today"""
        today = timezone.now().date()
        message_contains = f"Task {notification_type}"
        
        return NotificationLog.objects.filter(
            user=user,
            task_id=task_id,
            message__icontains=message_contains,
            created_at__date=today,
            status='SENT'
        ).exists()
    
    def _get_email_subject(self, task, notification_type):
        """Generate email subject"""
        if notification_type == 'start':
            return f"Task Starting: {task.task}"
        elif notification_type == 'due':
            return f"Task Due: {task.task}"
        return f"Task Update: {task.task}"
    
    def _get_email_message(self, task, notification_type):
        """Generate email message"""
        if notification_type == 'start':
            return f"""
Hello,

Your task "{task.task}" is starting today ({task.start.strftime('%Y-%m-%d')}).

Description: {task.desc}
Due Date: {task.end.strftime('%Y-%m-%d')}

Don't forget to work on it!

Best regards,
Your Todo App
"""
        elif notification_type == 'due':
            return f"""
Hello,

Your task "{task.task}" is due today ({task.end.strftime('%Y-%m-%d')}).

Description: {task.desc}
Started: {task.start.strftime('%Y-%m-%d')}

Please complete it as soon as possible!

Best regards,
Your Todo App
"""
        return f"Task update for: {task.task}"
    
    def _get_sms_message(self, task, notification_type):
        """Generate SMS message (shorter version)"""
        if notification_type == 'start':
            return f"📅 Task Starting: '{task.task}' - Due: {task.end.strftime('%m/%d')}"
        elif notification_type == 'due':
            return f"⏰ Task Due TODAY: '{task.task}' - Complete ASAP!"
        return f"Task update: {task.task}"
    
    def _get_whatsapp_message(self, task, notification_type):
        """Generate WhatsApp message"""
        if notification_type == 'start':
            return f"""🚀 *Task Starting Today!*

📋 *Task:* {task.task}
📅 *Due:* {task.end.strftime('%Y-%m-%d')}
📝 *Description:* {task.desc}

Good luck! 💪"""
        elif notification_type == 'due':
            return f"""⚠️ *Task Due Today!*

📋 *Task:* {task.task}
📅 *Due:* {task.end.strftime('%Y-%m-%d')}
📝 *Description:* {task.desc}

Please complete ASAP! ⏰"""
        return f"📱 Task update: {task.task}"
    
    def _log_notification(self, user, task_id, notification_type, message, status, error_message=None):
        """Log notification attempt"""
        NotificationLog.objects.create(
            user=user,
            task_id=task_id,
            notification_type=notification_type,
            message=message,
            status=status,
            error_message=error_message,
            sent_at=timezone.now() if status == 'SENT' else None
        )
    
    def _send_summary_email(self, user, summary_message):
        """Send daily summary via email"""
        try:
            prefs = NotificationPreference.objects.get(user=user)
            email = prefs.notification_email or user.email
            if not email:
                return False
            
            # Create HTML version of the summary
            html_message = self._format_summary_html(summary_message)
            
            from django.core.mail import send_mail
            send_mail(
                subject=f"📊 Daily Task Summary - {timezone.now().date()}",
                message=summary_message,  # Plain text fallback
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[email],
                fail_silently=False,
                html_message=html_message,  # HTML version
            )
            
            self._log_notification(user, 0, 'DAILY_SUMMARY_EMAIL', summary_message, 'SENT')
            return True
            
        except Exception as e:
            logger.error(f"Failed to send daily summary email: {str(e)}")
            self._log_notification(user, 0, 'DAILY_SUMMARY_EMAIL', str(e), 'FAILED', str(e))
            return False
    
    def _format_summary_html(self, summary_message):
        """Convert plain text summary to HTML"""
        lines = summary_message.split('\n')
        html = """
        <html>
        <body style="font-family: Arial, sans-serif; margin: 20px; color: #333;">
            <h2 style="color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px;">
                📊 Daily Task Summary
            </h2>
        """
        
        current_section = ""
        in_list = False
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            if line.startswith("Daily Summary for"):
                html += f'<p style="color: #7f8c8d; font-size: 14px;">{line}</p>'
            elif line.startswith("Tasks Starting Today") or line.startswith("Tasks Due Today"):
                if in_list:
                    html += "</ul>"
                html += f'<h3 style="color: #27ae60; margin-top: 20px;">{line}</h3>'
                html += '<ul style="margin-left: 20px;">'
                in_list = True
            elif line.startswith("•"):
                task_name = line[2:].strip()  # Remove bullet and spaces
                html += f'<li style="margin: 5px 0; padding: 5px; background: #f8f9fa; border-left: 3px solid #3498db;">{task_name}</li>'
        
        if in_list:
            html += "</ul>"
            
        html += """
            <hr style="margin: 30px 0; border: none; border-top: 1px solid #bdc3c7;">
            <p style="color: #95a5a6; font-size: 12px; text-align: center;">
                Have a productive day! 💪<br>
                Sent from your TODO Task Management System
            </p>
        </body>
        </html>
        """
        
        return html
    
    def _send_summary_whatsapp(self, user, summary_message):
        """Send daily summary via WhatsApp"""
        try:
            if not TWILIO_AVAILABLE:
                logger.warning("Twilio not available - WhatsApp summary skipped")
                return False
                
            prefs = NotificationPreference.objects.get(user=user)
            if not prefs.phone_number:
                return False
                
            # Format WhatsApp message
            whatsapp_message = f"📊 *Daily Task Summary*\n\n{summary_message}\n\nHave a productive day! 💪"
            
            # Send WhatsApp message
            whatsapp_from = f"whatsapp:{self.twilio_phone}"
            whatsapp_to = f"whatsapp:+{prefs.phone_number}"
            
            client = TwilioClient(self.twilio_sid, self.twilio_token)
            message_obj = client.messages.create(
                to=whatsapp_to,
                from_=whatsapp_from,
                body=whatsapp_message
            )
            
            self._log_notification(user, 0, 'DAILY_SUMMARY_WHATSAPP', whatsapp_message, 'SENT')
            return True
            
        except Exception as e:
            logger.error(f"Failed to send daily summary WhatsApp: {str(e)}")
            self._log_notification(user, 0, 'DAILY_SUMMARY_WHATSAPP', str(e), 'FAILED', str(e))
            return False
    
    def _send_summary_sms(self, user, summary_message):
        """Send daily summary via SMS"""
        try:
            if not TWILIO_AVAILABLE:
                logger.warning("Twilio not available - SMS summary skipped")
                return False
                
            prefs = NotificationPreference.objects.get(user=user)
            if not prefs.phone_number:
                return False
                
            # Shorten message for SMS
            sms_message = f"Daily Summary {timezone.now().date()}: {summary_message[:140]}..."
            
            client = TwilioClient(self.twilio_sid, self.twilio_token)
            message_obj = client.messages.create(
                to=f"+{prefs.phone_number}",
                from_=self.twilio_phone,
                body=sms_message
            )
            
            self._log_notification(user, 0, 'DAILY_SUMMARY_SMS', sms_message, 'SENT')
            return True
            
        except Exception as e:
            logger.error(f"Failed to send daily summary SMS: {str(e)}")
            self._log_notification(user, 0, 'DAILY_SUMMARY_SMS', str(e), 'FAILED', str(e))
            return False
