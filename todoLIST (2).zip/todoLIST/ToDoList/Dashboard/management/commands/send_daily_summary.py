from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import datetime
from Dashboard.models import NotificationPreference
from Dashboard.notification_service import NotificationService
from TaskManager.models import Task

class Command(BaseCommand):
    help = 'Send daily task summaries to all users who have it enabled'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be sent without actually sending',
        )

    def handle(self, *args, **options):
        self.stdout.write(
            self.style.SUCCESS(f'🕕 Starting daily summary at {datetime.now()}')
        )
        
        try:
            from django.contrib.auth import get_user_model
            User = get_user_model()
            
            # Get all users with daily summary enabled
            preferences = NotificationPreference.objects.filter(daily_summary=True)
            
            if not preferences.exists():
                self.stdout.write(
                    self.style.WARNING('❌ No users have daily summary enabled')
                )
                return
            
            self.stdout.write(f'Found {preferences.count()} users with daily summary enabled')
            
            notification_service = NotificationService()
            total_sent = 0
            
            for pref in preferences:
                user = pref.user
                self.stdout.write(f'\n📧 Processing daily summary for user: {user.username}')
                
                # Get user's tasks for today
                today = timezone.now().date()
                tasks_due_today = Task.objects.filter(
                    owner=user.username,
                    end=today,
                    status='INCOMPLETE'
                )
                
                tasks_starting_today = Task.objects.filter(
                    owner=user.username,
                    start=today,
                    status='INCOMPLETE'
                )
                
                self.stdout.write(f'   📅 Tasks due today: {tasks_due_today.count()}')
                self.stdout.write(f'   🚀 Tasks starting today: {tasks_starting_today.count()}')
                
                if tasks_due_today.exists() or tasks_starting_today.exists():
                    # Create a summary message with proper formatting
                    summary_message = f"Daily Summary for {today}:\n"
                    
                    if tasks_starting_today.exists():
                        summary_message += f"\nTasks Starting Today ({tasks_starting_today.count()}):\n"
                        for task in tasks_starting_today:
                            summary_message += f"• {task.task}\n"
                    
                    if tasks_due_today.exists():
                        summary_message += f"\nTasks Due Today ({tasks_due_today.count()}):\n" 
                        for task in tasks_due_today:
                            summary_message += f"• {task.task}\n"
                    
                    if options['dry_run']:
                        # Format for console display
                        display_message = summary_message.replace('\n', '\n      ')
                        self.stdout.write('📄 Summary message would be:')
                        self.stdout.write(f'      {display_message}')
                        self.stdout.write('   🔍 DRY RUN - No notifications sent')
                    else:
                        # Actually send the notifications
                        sent_channels = []
                        
                        if pref.email_notifications:
                            if notification_service._send_summary_email(user, summary_message):
                                sent_channels.append("Email")
                                self.stdout.write('   📧 ✅ Email summary sent!')
                            else:
                                self.stdout.write('   📧 ❌ Email failed')
                        
                        if pref.whatsapp_notifications:
                            if notification_service._send_summary_whatsapp(user, summary_message):
                                sent_channels.append("WhatsApp")
                                self.stdout.write('   📱 ✅ WhatsApp summary sent!')
                            else:
                                self.stdout.write('   📱 ❌ WhatsApp failed')
                        
                        if pref.sms_notifications:
                            if notification_service._send_summary_sms(user, summary_message):
                                sent_channels.append("SMS")
                                self.stdout.write('   📲 ✅ SMS summary sent!')
                            else:
                                self.stdout.write('   📲 ❌ SMS failed')
                        
                        if sent_channels:
                            self.stdout.write(
                                self.style.SUCCESS(f'   🎉 Daily summary sent via: {", ".join(sent_channels)}')
                            )
                            total_sent += 1
                        else:
                            self.stdout.write(
                                self.style.WARNING('   ⚠️  No summary sent - check configuration')
                            )
                else:
                    self.stdout.write('   ℹ️  No tasks for today - no summary needed')
            
            if not options['dry_run']:
                self.stdout.write(
                    self.style.SUCCESS(f'\\n🎉 Daily summary completed! Sent to {total_sent} users')
                )
            else:
                self.stdout.write(
                    self.style.SUCCESS('\\n🔍 Dry run completed - no notifications sent')
                )
                
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'❌ Error in daily summary: {str(e)}')
            )
            import traceback
            traceback.print_exc()
