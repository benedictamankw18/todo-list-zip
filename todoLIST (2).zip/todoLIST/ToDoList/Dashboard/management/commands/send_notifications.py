from django.core.management.base import BaseCommand
from django.utils import timezone
from Dashboard.notification_service import NotificationService
import logging

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Check and send task notifications for due and starting tasks'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Run without actually sending notifications',
        )

    def handle(self, *args, **options):
        self.stdout.write(
            self.style.SUCCESS(
                f'Starting notification check at {timezone.now()}'
            )
        )
        
        try:
            notification_service = NotificationService()
            
            if options['dry_run']:
                self.stdout.write(
                    self.style.WARNING('DRY RUN MODE - No notifications will be sent')
                )
                # Add dry run logic here if needed
                return
            
            # Check and send notifications
            notification_service.check_and_send_notifications()
            
            self.stdout.write(
                self.style.SUCCESS('Notification check completed successfully')
            )
            
        except Exception as e:
            logger.error(f"Error in notification command: {str(e)}")
            self.stdout.write(
                self.style.ERROR(f'Error: {str(e)}')
            )
            raise e
