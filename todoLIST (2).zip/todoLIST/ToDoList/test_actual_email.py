#!/usr/bin/env python
"""
Quick email sending test with current configuration
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.forms import PasswordResetForm
from Login.models import Login

def test_actual_email_sending():
    """Test sending actual email with current configuration"""
    print("🧪 TESTING ACTUAL EMAIL SENDING")
    print("=" * 50)
    print(f"📧 From: {settings.DEFAULT_FROM_EMAIL}")
    print(f"🌐 SMTP Host: {settings.EMAIL_HOST}")
    print(f"👤 SMTP User: {settings.EMAIL_HOST_USER}")
    
    # Test 1: Simple email
    try:
        print("\n📨 Sending test email...")
        send_mail(
            subject='Test Email - ToDoList',
            message='This is a test email to verify SMTP configuration.',
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=['nethunterghana@gmail.com'],  # Send to the configured email
            fail_silently=False,
        )
        print("✅ Test email sent successfully!")
        
    except Exception as e:
        print(f"❌ Test email failed: {e}")
        print("💡 This might be an authentication or network issue")
        return False
    
    # Test 2: Password reset email
    try:
        print("\n🔐 Testing password reset email...")
        form = PasswordResetForm({'email': 'nethunterghana@gmail.com'})
        if form.is_valid():
            form.save(
                request=None,
                use_https=False,
                from_email=settings.DEFAULT_FROM_EMAIL,
                email_template_name='password_reset_email.html',
                subject_template_name='password_reset_subject.txt'
            )
            print("✅ Password reset email sent successfully!")
            print("📱 Check your email: nethunterghana@gmail.com")
            return True
        else:
            print(f"❌ Password reset form invalid: {form.errors}")
            return False
            
    except Exception as e:
        print(f"❌ Password reset email failed: {e}")
        return False

def check_user_emails():
    """Check which users can receive password reset emails"""
    print("\n👥 CHECKING USER EMAILS FOR PASSWORD RESET")
    print("=" * 50)
    
    users = Login.objects.all()
    valid_users = []
    
    for user in users:
        if user.email:
            print(f"✅ {user.username}: {user.email}")
            valid_users.append(user)
        else:
            print(f"❌ {user.username}: No email address")
    
    if not valid_users:
        print("\n⚠️ No users have email addresses configured!")
        print("💡 Add email addresses to users in Django admin")
    else:
        print(f"\n📊 {len(valid_users)} users can receive password reset emails")
    
    return valid_users

if __name__ == "__main__":
    print("🚀 ACTUAL EMAIL SENDING TEST")
    print("=" * 60)
    
    # Check users first
    valid_users = check_user_emails()
    
    if valid_users:
        # Test actual email sending
        success = test_actual_email_sending()
        
        if success:
            print("\n🎉 EMAIL SENDING IS WORKING!")
            print("=" * 40)
            print("✅ SMTP configuration is correct")
            print("✅ Password reset emails should work")
            print("💡 Try password reset from the login page")
            print("📱 Check your inbox (and spam folder)")
        else:
            print("\n🚨 EMAIL SENDING FAILED")
            print("=" * 40)
            print("💡 Possible issues:")
            print("   - Gmail app password might be incorrect")
            print("   - Gmail might be blocking the app")
            print("   - Network connectivity issues")
            print("   - Need to restart Django server")
    else:
        print("\n⚠️ Cannot test email - no users with email addresses")
    
    print(f"\n🔧 If emails still don't work:")
    print(f"1. Restart Django server: Ctrl+C then python manage.py runserver")
    print(f"2. Check Gmail security settings")
    print(f"3. Generate new Gmail app password")
    print(f"4. Check spam/junk folder")
