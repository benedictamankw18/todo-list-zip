from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from Login.models import Login
import json

# Try to import 2FA dependencies, gracefully handle if not installed
try:
    import pyotp
    import qrcode
    import io
    import base64
    PYOTP_AVAILABLE = True
except ImportError:
    PYOTP_AVAILABLE = False

@login_required
def setup_2fa(request):
    """Setup 2FA for the current user"""
    if not PYOTP_AVAILABLE:
        return JsonResponse({
            'success': False, 
            'error': '2FA dependencies not installed. Please install: pip install pyotp qrcode[pil]'
        })
    
    try:
        user = request.user
        
        # Generate a secret key for this user
        secret = pyotp.random_base32()
        
        # Create TOTP object
        totp = pyotp.TOTP(secret)
        
        # Generate QR code
        qr_url = totp.provisioning_uri(
            name=user.username,
            issuer_name="Todo List App"
        )
        
        # Generate QR code image
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(qr_url)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to base64 for web display
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        img_str = base64.b64encode(buffer.getvalue()).decode()
        
        # Store the secret temporarily in session
        request.session['temp_2fa_secret'] = secret
        
        return JsonResponse({
            'success': True,
            'qr_code': f"data:image/png;base64,{img_str}",
            'secret': secret,
            'manual_entry': f"Secret Key: {secret}"
        })
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
def verify_2fa_setup(request):
    """Verify 2FA setup with user-provided token"""
    if not PYOTP_AVAILABLE:
        return JsonResponse({
            'success': False, 
            'error': '2FA dependencies not installed'
        })
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            token = data.get('token', '').strip()
            
            # Get temporary secret from session
            secret = request.session.get('temp_2fa_secret')
            
            if not secret:
                return JsonResponse({'success': False, 'error': 'No setup in progress'})
            
            # Verify the token
            totp = pyotp.TOTP(secret)
            if totp.verify(token):
                # Save the secret to user profile
                user = request.user
                # You might want to add a 2FA field to your user model
                # For now, we'll use session storage
                request.session['user_2fa_secret'] = secret
                request.session['2fa_enabled'] = True
                
                # Remove temporary secret
                del request.session['temp_2fa_secret']
                
                return JsonResponse({
                    'success': True, 
                    'message': '2FA has been successfully enabled for your account!'
                })
            else:
                return JsonResponse({'success': False, 'error': 'Invalid verification code'})
                
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def disable_2fa(request):
    """Disable 2FA for the current user"""
    if request.method == 'POST':
        try:
            # Remove 2FA from session (in a real app, remove from database)
            request.session.pop('user_2fa_secret', None)
            request.session.pop('2fa_enabled', None)
            
            return JsonResponse({
                'success': True, 
                'message': '2FA has been disabled for your account.'
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def get_2fa_status(request):
    """Get current 2FA status for the user"""
    is_enabled = request.session.get('2fa_enabled', False)
    return JsonResponse({
        'success': True,
        'enabled': is_enabled
    })

def verify_2fa_login(request):
    """Verify 2FA token during login process"""
    if not PYOTP_AVAILABLE:
        return JsonResponse({
            'success': False, 
            'error': '2FA dependencies not installed'
        })
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            token = data.get('token', '').strip()
            username = request.session.get('2fa_username')
            
            if not username:
                return JsonResponse({'success': False, 'error': 'No 2FA session found'})
            
            # Get user's 2FA secret (in a real app, from database)
            # For demo purposes, we'll use a default
            secret = request.session.get('user_2fa_secret')
            
            if not secret:
                return JsonResponse({'success': False, 'error': '2FA not set up'})
            
            # Verify the token
            totp = pyotp.TOTP(secret)
            if totp.verify(token):
                # Complete login process
                request.session.pop('2fa_username', None)
                return JsonResponse({
                    'success': True, 
                    'message': '2FA verification successful!',
                    'redirect': '/dashboard/'
                })
            else:
                return JsonResponse({'success': False, 'error': 'Invalid verification code'})
                
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})
