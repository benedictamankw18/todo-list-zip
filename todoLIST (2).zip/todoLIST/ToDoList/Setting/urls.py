from django.urls import path
from . import views
from . import views_2fa_simple as views_2fa

urlpatterns = [
    path('', views.setting, name='Setting'),
    path('2fa/setup/', views_2fa.setup_2fa, name='setup_2fa'),
    path('2fa/verify/', views_2fa.verify_2fa_setup, name='verify_2fa_setup'),
    path('2fa/disable/', views_2fa.disable_2fa, name='disable_2fa'),
    path('2fa/status/', views_2fa.get_2fa_status, name='get_2fa_status'),
    path('2fa/verify-login/', views_2fa.verify_2fa_login, name='verify_2fa_login'),
    
    # Social account management
    path('social/add/', views.add_social, name='add_social'),
    path('social/update/', views.update_social, name='update_social'),
    path('social/delete/', views.delete_social, name='delete_social'),
]