#!/usr/bin/env python
"""
Test web interface password reset to ensure proper email formatting
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from django.test import Client
from django.contrib.auth.forms import PasswordResetForm
from django.template.loader import render_to_string
from django.core.mail import EmailMultiAlternatives
from django.conf import settings
from Login.models import Login

def test_web_interface_password_reset():
    """Test password reset through web interface to ensure proper email formatting"""
    print("🌐 TESTING WEB INTERFACE PASSWORD RESET")
    print("=" * 60)
    
    # Create a test client
    client = Client()
    
    # Test the password reset page
    print("📄 Testing password reset page...")
    response = client.get('/password-reset/')
    
    if response.status_code == 200:
        print("✅ Password reset page loads correctly")
    else:
        print(f"❌ Password reset page failed: {response.status_code}")
        return False
    
    # Test form submission
    print("\n📧 Testing form submission...")
    response = client.post('/password-reset/', {
        'email': 'benedictamankwa18@gmail.com'
    })
    
    if response.status_code == 302:  # Redirect to success page
        print("✅ Form submission successful - redirected to success page")
    else:
        print(f"❌ Form submission failed: {response.status_code}")
        return False
    
    print("✅ Web interface password reset test completed!")
    return True

def test_multipart_email_sending():
    """Test sending multipart email (HTML + plain text)"""
    print("\n📨 TESTING MULTIPART EMAIL SENDING")
    print("=" * 60)
    
    # Get test user
    user = Login.objects.filter(email='benedictamankwa18@gmail.com').first()
    if not user:
        print("❌ User with email benedictamankwa18@gmail.com not found")
        return False
    
    print(f"👤 Sending to: {user.username} ({user.email})")
    
    # Create context for templates
    from django.utils.http import urlsafe_base64_encode
    from django.utils.encoding import force_bytes
    from django.contrib.auth.tokens import default_token_generator
    
    domain = '127.0.0.1:8000'
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = default_token_generator.make_token(user)
    
    context = {
        'user': user,
        'protocol': 'http',
        'domain': domain,
        'uid': uid,
        'token': token,
    }
    
    try:
        # Render both HTML and plain text templates
        subject = render_to_string('password_reset_subject.txt', context).strip()
        html_message = render_to_string('password_reset_email.html', context)
        text_message = render_to_string('password_reset_email.txt', context)
        
        print(f"📧 Subject: {subject}")
        print(f"📄 HTML template rendered: {len(html_message)} characters")
        print(f"📝 Text template rendered: {len(text_message)} characters")
        
        # Create multipart email
        email = EmailMultiAlternatives(
            subject=subject,
            body=text_message,  # Plain text version
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[user.email],
        )
        
        # Attach HTML version
        email.attach_alternative(html_message, "text/html")
        
        # Send email
        email.send()
        
        print(f"✅ Multipart email sent successfully!")
        print(f"📬 Sent to: {user.email}")
        print(f"🔗 Reset URL: http://127.0.0.1:8000/password-reset-confirm/{uid}/{token}/")
        print(f"📱 Email contains both HTML and plain text versions")
        
        return True
        
    except Exception as e:
        print(f"❌ Multipart email sending failed: {e}")
        return False

def show_email_troubleshooting():
    """Show troubleshooting tips for email display issues"""
    print(f"\n🔧 EMAIL DISPLAY TROUBLESHOOTING")
    print("=" * 60)
    print("""
📧 WHY EMAILS SHOW HTML CODE INSTEAD OF UI:

🔍 COMMON CAUSES:
1. Email client doesn't support HTML emails
2. Email sent as plain text only (no HTML alternative)
3. Incorrect MIME type headers
4. Email client security settings blocking HTML

✅ SOLUTIONS IMPLEMENTED:
1. Created both HTML and plain text email templates
2. Using EmailMultiAlternatives for proper multipart emails
3. Setting correct MIME types (text/html and text/plain)
4. Updated password reset view to use both templates

📱 EMAIL CLIENT RECOMMENDATIONS:
- Gmail: Excellent HTML support ✅
- Outlook: Good HTML support ✅
- Apple Mail: Excellent HTML support ✅
- Thunderbird: Good HTML support ✅
- Basic email clients: Will show plain text version ✅

🧪 TESTING CHECKLIST:
1. Check both HTML and plain text versions are sent
2. Verify email headers include multipart/alternative
3. Test in different email clients
4. Check spam folder for HTML rendering issues

💡 IF STILL SHOWING HTML CODE:
- Try a different email client (Gmail web interface)
- Check email client HTML settings
- Verify email isn't being converted to plain text by firewall
- Test with a different email address
""")

if __name__ == "__main__":
    print("🚀 WEB INTERFACE EMAIL FORMATTING TEST")
    print("=" * 70)
    
    # Test 1: Web interface
    web_ok = test_web_interface_password_reset()
    
    if web_ok:
        # Test 2: Multipart email
        email_ok = test_multipart_email_sending()
        
        if email_ok:
            print(f"\n🎉 WEB INTERFACE EMAIL IS WORKING!")
            print("=" * 50)
            print("✅ Password reset form works correctly")
            print("✅ Multipart emails are being sent")
            print("✅ Both HTML and plain text versions included")
            print("📱 Email should display properly in all clients")
        else:
            print(f"\n🚨 EMAIL SENDING FAILED")
            print("Web interface works but email delivery failed")
    else:
        print(f"\n🚨 WEB INTERFACE FAILED")
        print("Need to fix web interface before testing emails")
    
    # Always show troubleshooting info
    show_email_troubleshooting()
    
    print(f"\n💡 NEXT STEPS:")
    print(f"1. Check email inbox (including spam folder)")
    print(f"2. Try password reset from: http://127.0.0.1:8000/password-reset/")
    print(f"3. Verify email displays as proper UI (not HTML code)")
    print(f"4. Test reset link functionality")
