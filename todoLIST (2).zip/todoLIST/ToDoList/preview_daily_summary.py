#!/usr/bin/env python
"""
Preview Daily Summary Email Format
"""
import os
import sys
import django

# Set up Django
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Dashboard.notification_service import NotificationService

def preview_summary_format():
    """Show what the daily summary email looks like"""
    
    # Sample summary message
    summary_message = """Daily Summary for 2025-07-14:

Tasks Starting Today (3):
• Complete project documentation
• Review team performance reports  
• Prepare monthly budget presentation

Tasks Due Today (2):
• Submit quarterly financial report
• Send client proposal follow-up"""

    print("📧 PLAIN TEXT VERSION:")
    print("=" * 50)
    print(summary_message)
    print("=" * 50)
    
    print("\n🎨 HTML EMAIL VERSION:")
    print("=" * 50)
    
    # Create notification service and format HTML
    service = NotificationService()
    html_content = service._format_summary_html(summary_message)
    
    # Save HTML to file for viewing
    with open('preview_daily_summary.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print("HTML email saved to: preview_daily_summary.html")
    print("Open this file in your browser to see the formatted email!")
    print("=" * 50)
    
    print("\n✨ EMAIL FEATURES:")
    print("• Professional HTML formatting")
    print("• Color-coded sections") 
    print("• Clean typography")
    print("• Bullet points with styling")
    print("• Mobile-friendly design")
    print("• Branded footer")

if __name__ == "__main__":
    preview_summary_format()
