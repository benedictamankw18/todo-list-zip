#!/usr/bin/env python
"""
Test 2FA Implementation
Run this to test the basic 2FA functionality
"""

import os
import django
import sys

# Add the project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

try:
    import pyotp
    import qrcode
    
    print("✅ 2FA Dependencies Test")
    print("=" * 40)
    
    # Test TOTP generation
    secret = pyotp.random_base32()
    print(f"📝 Generated Secret: {secret}")
    
    # Test TOTP object creation
    totp = pyotp.TOTP(secret)
    current_token = totp.now()
    print(f"🔢 Current Token: {current_token}")
    
    # Test token verification
    is_valid = totp.verify(current_token)
    print(f"✅ Token Verification: {'PASSED' if is_valid else 'FAILED'}")
    
    # Test QR code generation
    qr_url = totp.provisioning_uri(
        name="test_user",
        issuer_name="Todo List App Test"
    )
    print(f"🔗 QR URL: {qr_url}")
    
    # Test QR code image creation
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(qr_url)
    qr.make(fit=True)
    print("🖼️  QR Code Image: Generated successfully")
    
    print("\n🎉 All 2FA tests passed!")
    print("2FA functionality is ready to use.")
    
except ImportError as e:
    print(f"❌ Missing dependency: {e}")
    print("Please install: pip install qrcode[pil] pyotp")
except Exception as e:
    print(f"❌ Error: {e}")
