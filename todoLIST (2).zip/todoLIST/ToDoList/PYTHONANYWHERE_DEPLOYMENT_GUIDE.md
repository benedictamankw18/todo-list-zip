# 🚀 PYTHONANYWHERE DEPLOYMENT & AUTOMATIC NOTIFICATIONS

## 📋 OVERVIEW

Your Django TODO app with SMS/Email/WhatsApp notifications is ready for PythonAnywhere hosting!

---

## 🔧 PYTHONANYWHERE SETUP

### **1. File Upload & Structure**

Upload your project maintaining this structure:

```
/home/yourusername/
├── todolist/                 # Your Django project
│   ├── manage.py
│   ├── ToDoList/
│   ├── Dashboard/
│   ├── Login/
│   ├── Setting/
│   ├── TaskManager/
│   ├── Welcome/
│   ├── static/
│   └── requirements.txt
└── .env                      # Environment variables
```

### **2. Environment Variables (.env)**

Create `/home/yourusername/.env` with your credentials:

```bash
# Django Settings
DEBUG=False
SECRET_KEY=your-secure-secret-key-here
ALLOWED_HOSTS=yourusername.pythonanywhere.com

# Email Settings (Gmail)
EMAIL_HOST_USER=nethunterghana@gmail.com
EMAIL_HOST_PASSWORD=pagg glrb zyta rfth
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
DEFAULT_FROM_EMAIL=benedictamankwa9@gmail.com

# Twilio Settings (Working!)
TWILIO_ACCOUNT_SID=AC1bc86f27054f6efb6c4ff33a41f8d170
TWILIO_AUTH_TOKEN=4a1a8ffe69310dd17bead68f5f445fc7
TWILIO_PHONE_NUMBER=+18595497175

# WhatsApp via Twilio (Working!)
WHATSAPP_FROM_NUMBER=whatsapp:+14155238886
WHATSAPP_CONTENT_SID=HXb5b62575e6e4ff6129ad7c8efe1f983e

# Database (PythonAnywhere MySQL)
DATABASE_URL=mysql://username:password@username.mysql.pythonanywhere-services.com/username$todolist

# Logging
LOG_LEVEL=INFO
```

### **3. Requirements.txt**

Create/update `requirements.txt`:

```
Django==5.2.4
python-decouple==3.8
python-dotenv==1.0.0
twilio==9.0.4
requests==2.31.0
mysqlclient==2.2.0
```

---

## ⏰ AUTOMATIC NOTIFICATIONS ON PYTHONANYWHERE

### **Option 1: PythonAnywhere Tasks (RECOMMENDED)**

**Free Account**: 1 scheduled task allowed
**Paid Account**: Multiple scheduled tasks

1. **Go to PythonAnywhere Dashboard**

   - Click "Tasks" tab
   - Click "Create a new scheduled task"

2. **Configure Task**

   - **Command**: `/home/yourusername/.virtualenvs/todolist/bin/python /home/yourusername/todolist/manage.py send_notifications`
   - **Hour**: `*` (every hour)
   - **Minute**: `0,15,30,45` (every 15 minutes)
   - **Description**: "Send task notifications"

3. **Alternative - Every 30 minutes** (for free accounts):
   - **Minute**: `0,30`
   - **Hour**: `8-18` (business hours only)

### **Option 2: Cron-style with Always-On Tasks**

For paid accounts with "Always-On Tasks":

1. **Create notification daemon script** (`notification_daemon.py`):

```python
#!/usr/bin/env python
import os
import django
import time
import logging
from datetime import datetime

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Dashboard.notification_service import NotificationService

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/yourusername/notification_daemon.log'),
        logging.StreamHandler()
    ]
)

def run_notifications():
    try:
        service = NotificationService()
        service.check_and_send_notifications()
        logging.info("Notifications checked successfully")
    except Exception as e:
        logging.error(f"Error in notifications: {str(e)}")

if __name__ == "__main__":
    logging.info("Starting notification daemon...")

    while True:
        current_time = datetime.now()
        logging.info(f"Running notification check at {current_time}")

        run_notifications()

        # Wait 15 minutes (900 seconds)
        time.sleep(900)
```

2. **Run as Always-On Task**:
   - Command: `/home/yourusername/.virtualenvs/todolist/bin/python /home/yourusername/notification_daemon.py`

---

## 🔧 PYTHONANYWHERE CONFIGURATION UPDATES

### **1. Update Django Settings for PythonAnywhere**

Add to `ToDoList/settings.py`:

```python
# PythonAnywhere specific settings
import os
from decouple import config

# Security
ALLOWED_HOSTS = [
    'yourusername.pythonanywhere.com',
    'localhost',
    '127.0.0.1'
]

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = '/home/yourusername/todolist/static'

# Database - Use environment variable for flexibility
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': config('DB_NAME', default='yourusername$todolist'),
        'USER': config('DB_USER', default='yourusername'),
        'PASSWORD': config('DB_PASSWORD'),
        'HOST': config('DB_HOST', default='yourusername.mysql.pythonanywhere-services.com'),
        'PORT': '',
    }
}

# Email backend for production
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'

# Logging for PythonAnywhere
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'file': {
            'level': 'INFO',
            'class': 'logging.FileHandler',
            'filename': '/home/yourusername/django.log',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['file'],
            'level': 'INFO',
            'propagate': True,
        },
        'Dashboard.notification_service': {
            'handlers': ['file'],
            'level': 'INFO',
            'propagate': True,
        },
    },
}
```

### **2. Update WSGI Configuration**

In PythonAnywhere Web tab, update WSGI file:

```python
import os
import sys
from dotenv import load_dotenv

# Add your project directory to the sys.path
path = '/home/yourusername/todolist'
if path not in sys.path:
    sys.path.insert(0, path)

# Load environment variables
load_dotenv('/home/yourusername/.env')

os.environ['DJANGO_SETTINGS_MODULE'] = 'ToDoList.settings'

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
```

---

## 📋 DEPLOYMENT CHECKLIST

### **Phase 1: Initial Setup**

- [ ] Upload project files to PythonAnywhere
- [ ] Create virtual environment: `mkvirtualenv todolist --python=python3.10`
- [ ] Install requirements: `pip install -r requirements.txt`
- [ ] Create MySQL database in PythonAnywhere dashboard
- [ ] Update `.env` file with PythonAnywhere credentials
- [ ] Run migrations: `python manage.py migrate`
- [ ] Create superuser: `python manage.py createsuperuser`
- [ ] Collect static files: `python manage.py collectstatic`

### **Phase 2: Web App Configuration**

- [ ] Create new web app in PythonAnywhere dashboard
- [ ] Configure WSGI file
- [ ] Set static files mapping: `/static/` → `/home/yourusername/todolist/static/`
- [ ] Test web application loads

### **Phase 3: Notification Setup**

- [ ] Test manual notifications: `python manage.py send_notifications`
- [ ] Create scheduled task for automatic notifications
- [ ] Test notification delivery (Email + WhatsApp)
- [ ] Monitor logs for any issues

### **Phase 4: Final Testing**

- [ ] Test user registration and login
- [ ] Test task creation and management
- [ ] Test notification settings page
- [ ] Verify automatic notifications work
- [ ] Test all three notification channels

---

## 🎯 RECOMMENDED CONFIGURATION

**For Free PythonAnywhere Account:**

- **Schedule**: Every 30 minutes during business hours (8 AM - 6 PM)
- **Command**: `python manage.py send_notifications`
- **Monitoring**: Check logs daily

**For Paid PythonAnywhere Account:**

- **Schedule**: Every 15 minutes, 24/7
- **Always-On Task**: Notification daemon for real-time processing
- **Monitoring**: Automated log analysis

---

## 🚀 GO LIVE STEPS

1. **Upload and configure** (1-2 hours)
2. **Test thoroughly** (30 minutes)
3. **Enable scheduled notifications** (15 minutes)
4. **Monitor first day** (ongoing)

Your Django TODO app with Email + WhatsApp notifications will be **fully operational** on PythonAnywhere! 🎉
