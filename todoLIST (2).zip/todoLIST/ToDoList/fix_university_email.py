#!/usr/bin/env python
"""
Quick fix for University user email synchronization
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login
from Dashboard.models import NotificationPreference

def fix_university_user():
    """Fix the University user email issue"""
    try:
        # Get University user
        uni_user = Login.objects.get(username='University')
        pref = NotificationPreference.objects.get(user=uni_user)
        
        print(f"University User Analysis:")
        print(f"  Username: {uni_user.username}")
        print(f"  User email: '{uni_user.email}' (length: {len(uni_user.email or '')})")
        print(f"  Notification email: '{pref.notification_email}'")
        
        # Check if user email is empty/None and notification email exists
        if (not uni_user.email or uni_user.email.strip() == '') and pref.notification_email:
            print(f"\n🔧 Fixing: Copying notification email to user email")
            uni_user.email = pref.notification_email
            uni_user.save()
            print(f"✅ SUCCESS: University user email updated to '{uni_user.email}'")
            
            # Verify the fix
            uni_user.refresh_from_db()
            print(f"✅ VERIFIED: User email is now '{uni_user.email}'")
            
        elif uni_user.email and not pref.notification_email:
            print(f"\n🔧 Fixing: Copying user email to notification preferences")
            pref.notification_email = uni_user.email
            pref.save()
            print(f"✅ SUCCESS: Notification email updated to '{pref.notification_email}'")
            
        elif uni_user.email and pref.notification_email and uni_user.email != pref.notification_email:
            print(f"\n⚠️ MISMATCH: User email '{uni_user.email}' != Notification email '{pref.notification_email}'")
            print(f"   Syncing notification email to match user email...")
            pref.notification_email = uni_user.email
            pref.save()
            print(f"✅ SUCCESS: Emails synchronized")
            
        else:
            print(f"\n✅ NO ACTION NEEDED: Emails are already synchronized")
            
    except Login.DoesNotExist:
        print("❌ University user not found")
    except NotificationPreference.DoesNotExist:
        print("❌ University user has no notification preferences")
    except Exception as e:
        print(f"❌ Error: {e}")

def show_all_users_status():
    """Show current status of all users"""
    print(f"\n📊 ALL USERS EMAIL STATUS:")
    print("=" * 60)
    
    for user in Login.objects.all():
        try:
            pref = NotificationPreference.objects.get(user=user)
            user_email = user.email or "None"
            notif_email = pref.notification_email or "None"
            
            if user_email == notif_email:
                status = "✅ SYNCED"
            elif not user.email and pref.notification_email:
                status = "⚠️ USER EMAIL EMPTY"
            elif user.email and not pref.notification_email:
                status = "⚠️ NOTIFICATION EMAIL EMPTY"
            else:
                status = "❌ DIFFERENT"
                
            print(f"👤 {user.username:12} | User: {user_email:25} | Notif: {notif_email:25} | {status}")
            
        except NotificationPreference.DoesNotExist:
            print(f"👤 {user.username:12} | User: {user.email or 'None':25} | Notif: {'NO PREFERENCES':25} | ❌ MISSING")

if __name__ == "__main__":
    print("🔧 University User Email Fix Tool")
    print("=" * 50)
    
    fix_university_user()
    show_all_users_status()
    
    print(f"\n🎯 Next step: Run sync command again to verify:")
    print(f"   python manage.py sync_emails --dry-run")
