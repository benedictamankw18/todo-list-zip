# Django TODO Notification Automation Script
# This script runs the notification system and logs the results

# Get current timestamp
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

# Navigate to project directory
Set-Location "E:\todoLIST\ToDoList"

# Activate virtual environment
try {
    & "E:\todoLIST\todo-list-new\Scripts\Activate.ps1"
    Write-Host "[$timestamp] Virtual environment activated"
    
    # Run notification check
    Write-Host "[$timestamp] Running notification check..."
    python manage.py send_notifications
    
    # Log success
    $logEntry = "[$timestamp] SUCCESS - Notifications checked and sent"
    Add-Content -Path "notification_automation.log" -Value $logEntry
    Write-Host $logEntry -ForegroundColor Green
    
}
catch {
    # Log error
    $errorMsg = "[$timestamp] ERROR - $($_.Exception.Message)"
    Add-Content -Path "notification_automation.log" -Value $errorMsg
    Write-Host $errorMsg -ForegroundColor Red
}

Write-Host "[$timestamp] Notification automation complete"
