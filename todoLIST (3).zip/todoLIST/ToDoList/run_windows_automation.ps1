# Windows Task Scheduler PowerShell Script
# This script sets up automatic scheduling for Windows development

$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Write-Host "[$timestamp] Starting Windows automation..."

# Navigate to project directory
Set-Location "E:\todoLIST\ToDoList"

try {
    # Activate virtual environment
    & "E:\todoLIST\todo-list-new\Scripts\Activate.ps1"
    Write-Host "[$timestamp] Virtual environment activated"
    
    # Run automation
    Write-Host "[$timestamp] Running automation..."
    python windows_automation.py
    
    # Log success
    $logEntry = "[$timestamp] SUCCESS - Windows automation completed"
    Add-Content -Path "windows_automation_log.txt" -Value $logEntry
    Write-Host $logEntry -ForegroundColor Green
    
}
catch {
    # Log error
    $errorMsg = "[$timestamp] ERROR - $($_.Exception.Message)"
    Add-Content -Path "windows_automation_log.txt" -Value $errorMsg
    Write-Host $errorMsg -ForegroundColor Red
    exit 1
}

Write-Host "[$timestamp] Automation run completed"
