#!/usr/bin/env python3
"""
PythonAnywhere Notification Test Script
Test this before setting up automatic scheduling
"""

import os
import sys
import django
from datetime import datetime

# Add project path (update with your PythonAnywhere username)
USERNAME = 'yourusername'  # CHANGE THIS!
project_path = f'/home/{USERNAME}/todolist'

if project_path not in sys.path:
    sys.path.insert(0, project_path)

# Load environment
from dotenv import load_dotenv
load_dotenv(f'/home/{USERNAME}/.env')

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

def test_notifications():
    """Test notification system on PythonAnywhere"""
    print("🔍 TESTING PYTHONANYWHERE NOTIFICATIONS")
    print("=" * 50)
    print(f"Time: {datetime.now()}")
    print(f"Python path: {sys.executable}")
    print(f"Project path: {project_path}")
    
    try:
        # Test imports
        from Dashboard.notification_service import NotificationService
        from Login.models import Login
        from Dashboard.models import NotificationPreference
        
        print("✅ Django imports successful")
        
        # Test database connection
        user_count = Login.objects.count()
        print(f"✅ Database connection: {user_count} users found")
        
        # Test notification service
        service = NotificationService()
        print("✅ Notification service created")
        
        # Test credentials
        print(f"📧 Email configured: {bool(os.getenv('EMAIL_HOST_USER'))}")
        print(f"📱 Twilio configured: {bool(os.getenv('TWILIO_ACCOUNT_SID'))}")
        print(f"💬 WhatsApp configured: {bool(os.getenv('WHATSAPP_FROM_NUMBER'))}")
        
        # Run dry notification check
        print("\n🧪 Running dry notification check...")
        service.check_and_send_notifications()
        print("✅ Notification check completed successfully!")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_notifications()
    if success:
        print("\n🎉 ALL TESTS PASSED!")
        print("Your notification system is ready for PythonAnywhere!")
        print("\nNext steps:")
        print("1. Set up scheduled task in PythonAnywhere dashboard")
        print("2. Command: python3.10 /home/yourusername/todolist/pythonanywhere_notifications.py")
        print("3. Schedule: Every 15-30 minutes")
    else:
        print("\n❌ TESTS FAILED!")
        print("Please fix the errors above before deploying.")
