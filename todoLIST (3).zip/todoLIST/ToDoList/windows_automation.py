#!/usr/bin/env python3
"""
Windows Task Scheduler Automation Script
This script sets up automatic notifications for Windows development
"""

import os
import sys
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path

# Add project to path
project_path = Path(__file__).parent
sys.path.insert(0, str(project_path))

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
import django
django.setup()

# Configure logging
log_file = project_path / 'windows_automation.log'
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class WindowsNotificationService:
    """Windows-specific notification automation"""
    
    def __init__(self):
        self.last_daily_summary = None
        self.load_state()
    
    def load_state(self):
        """Load last execution state"""
        state_file = Path(__file__).parent / 'automation_state.txt'
        if state_file.exists():
            try:
                with open(state_file, 'r') as f:
                    date_str = f.read().strip()
                    if date_str:
                        self.last_daily_summary = datetime.strptime(date_str, '%Y-%m-%d').date()
            except Exception as e:
                logger.warning(f"Could not load state: {e}")
    
    def save_state(self):
        """Save execution state"""
        state_file = Path(__file__).parent / 'automation_state.txt'
        try:
            with open(state_file, 'w') as f:
                if self.last_daily_summary:
                    f.write(self.last_daily_summary.strftime('%Y-%m-%d'))
        except Exception as e:
            logger.error(f"Could not save state: {e}")
    
    def run_notifications(self):
        """Run notification check"""
        try:
            logger.info("🔔 Starting notification check...")
            
            from Dashboard.notification_service import NotificationService
            service = NotificationService()
            service.check_and_send_notifications()
            
            logger.info("✅ Notification check completed")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error in notifications: {str(e)}")
            return False
    
    def run_daily_summary(self):
        """Run daily summary if needed"""
        try:
            current_date = datetime.now().date()
            current_hour = datetime.now().hour
            
            # Send daily summary at 8 AM if not sent today
            if (current_hour >= 8 and 
                (self.last_daily_summary is None or current_date > self.last_daily_summary)):
                
                logger.info("📊 Starting daily summary...")
                
                from Dashboard.tasks import send_daily_summary
                send_daily_summary()
                
                self.last_daily_summary = current_date
                self.save_state()
                
                logger.info("✅ Daily summary completed")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Error in daily summary: {str(e)}")
            return False
    
    def run_all(self):
        """Run all automation tasks"""
        logger.info("🚀 Starting Windows automation...")
        
        # Run notifications
        notification_success = self.run_notifications()
        
        # Run daily summary if needed
        summary_success = self.run_daily_summary()
        
        if notification_success:
            logger.info("✅ Automation completed successfully")
        else:
            logger.error("❌ Automation completed with errors")
        
        return notification_success

def main():
    """Main function"""
    service = WindowsNotificationService()
    service.run_all()

if __name__ == "__main__":
    main()
