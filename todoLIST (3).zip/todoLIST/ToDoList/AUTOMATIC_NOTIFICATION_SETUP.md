# 🕐 AUTOMATIC NOTIFICATION SETUP GUIDE

## ❌ CURRENT STATUS: Manual Only

**Notifications currently require manual execution:** `python manage.py send_notifications`

## ✅ SOLUTIONS: Make Notifications Automatic

### **Option 1: Windows Task Scheduler (RECOMMENDED)**

1. **Open Task Scheduler**

   - Press `Win + R`, type `taskschd.msc`, press Enter

2. **Create New Task**

   - Right-click "Task Scheduler Library" → "Create Basic Task"
   - Name: "Django TODO Notifications"
   - Description: "Send task due notifications every 15 minutes"

3. **Set Trigger**

   - Trigger: "Daily"
   - Start time: "12:00 AM"
   - Recur every: "1 day"
   - Check "Repeat task every: 15 minutes"
   - Duration: "1 day"

4. **Set Action**

   - Action: "Start a program"
   - Program: `E:\todoLIST\todo-list-new\Scripts\python.exe`
   - Arguments: `manage.py send_notifications`
   - Start in: `E:\todoLIST\ToDoList`

5. **Save and Test**

### **Option 2: PowerShell Script (Alternative)**

Create `run_notifications.ps1`:

```powershell
# Navigate to project directory
Set-Location "E:\todoLIST\ToDoList"

# Activate virtual environment and run notifications
& "E:\todoLIST\todo-list-new\Scripts\Activate.ps1"
python manage.py send_notifications

# Log the execution
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Add-Content -Path "notification_log.txt" -Value "$timestamp - Notifications checked"
```

Then schedule this PowerShell script to run every 15 minutes.

### **Option 3: Celery + Redis (Advanced)**

For more robust production setup:

1. **Install Celery**

   ```bash
   pip install celery redis django-celery-beat
   ```

2. **Configure in settings.py**

   ```python
   # Celery settings
   CELERY_BROKER_URL = 'redis://localhost:6379/0'
   CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'
   CELERY_BEAT_SCHEDULE = {
       'send-notifications': {
           'task': 'Dashboard.tasks.send_notifications_task',
           'schedule': 900.0,  # Every 15 minutes
       },
   }
   ```

3. **Create Celery task**

   ```python
   # Dashboard/tasks.py
   from celery import shared_task
   from .notification_service import NotificationService

   @shared_task
   def send_notifications_task():
       service = NotificationService()
       service.check_and_send_notifications()
   ```

---

## 🎯 **QUICK SETUP: Windows Task Scheduler**

**For immediate automatic notifications, use Windows Task Scheduler:**

1. **Run every 15 minutes** (matches your notification preferences)
2. **Command**: `python manage.py send_notifications`
3. **Location**: Your Django project directory
4. **Zero additional dependencies** needed

This will check for due tasks every 15 minutes and send Email + WhatsApp notifications automatically!

---

## ⏰ **Timing Recommendations**

- **Every 15 minutes**: Responsive but not overwhelming
- **Every 30 minutes**: Good balance for most users
- **Every hour**: Less frequent but still effective
- **Business hours only**: 8 AM - 6 PM to avoid late-night notifications

Choose the frequency that works best for your users!
