#!/usr/bin/env python
"""
Email Configuration and Testing Tool for Password Reset
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from django.core.mail import send_mail
from django.test import override_settings
from django.conf import settings
from django.contrib.auth.forms import PasswordResetForm
from Login.models import Login

def check_email_settings():
    """Check current email configuration"""
    print("📧 CURRENT EMAIL CONFIGURATION")
    print("=" * 50)
    print(f"EMAIL_BACKEND: {getattr(settings, 'EMAIL_BACKEND', 'Not set')}")
    print(f"EMAIL_HOST: {getattr(settings, 'EMAIL_HOST', 'Not set')}")
    print(f"EMAIL_PORT: {getattr(settings, 'EMAIL_PORT', 'Not set')}")
    print(f"EMAIL_USE_TLS: {getattr(settings, 'EMAIL_USE_TLS', 'Not set')}")
    print(f"EMAIL_HOST_USER: {getattr(settings, 'EMAIL_HOST_USER', 'Not set')}")
    print(f"EMAIL_HOST_PASSWORD: {'***' if getattr(settings, 'EMAIL_HOST_PASSWORD', None) else 'Not set'}")
    print(f"DEFAULT_FROM_EMAIL: {getattr(settings, 'DEFAULT_FROM_EMAIL', 'Not set')}")

def test_console_email():
    """Test email with console backend"""
    print("\n🧪 TESTING WITH CONSOLE BACKEND")
    print("=" * 50)
    
    with override_settings(EMAIL_BACKEND='django.core.mail.backends.console.EmailBackend'):
        try:
            send_mail(
                'Test Password Reset - ToDoList',
                'This is a test password reset email.',
                'noreply@todolist.com',
                ['test@example.com'],
                fail_silently=False,
            )
            print("✅ Console email test successful! (Check terminal output above)")
            return True
        except Exception as e:
            print(f"❌ Console email test failed: {e}")
            return False

def test_password_reset_for_user(email):
    """Test password reset for a specific user"""
    print(f"\n🔐 TESTING PASSWORD RESET FOR: {email}")
    print("=" * 50)
    
    try:
        # Check if user exists
        user = Login.objects.filter(email=email).first()
        if not user:
            print(f"❌ No user found with email: {email}")
            print("Available users:")
            for u in Login.objects.all():
                print(f"  - {u.username}: {u.email}")
            return False
        
        print(f"✅ User found: {user.username}")
        
        # Test with console backend first
        print("\n📧 Testing with console backend...")
        with override_settings(EMAIL_BACKEND='django.core.mail.backends.console.EmailBackend'):
            form = PasswordResetForm({'email': email})
            if form.is_valid():
                form.save(
                    request=None,
                    use_https=False,
                    from_email='noreply@todolist.com',
                    email_template_name='password_reset_email.html',
                    subject_template_name='password_reset_subject.txt'
                )
                print("✅ Password reset email sent to console!")
            else:
                print(f"❌ Form validation failed: {form.errors}")
                return False
        
        # Test with actual SMTP if credentials are available
        if settings.EMAIL_HOST_USER and settings.EMAIL_HOST_PASSWORD:
            print("\n📨 Testing with SMTP backend...")
            form = PasswordResetForm({'email': email})
            if form.is_valid():
                try:
                    form.save(
                        request=None,
                        use_https=False,
                        from_email=settings.DEFAULT_FROM_EMAIL or 'noreply@todolist.com',
                        email_template_name='password_reset_email.html',
                        subject_template_name='password_reset_subject.txt'
                    )
                    print("✅ Password reset email sent via SMTP!")
                    print(f"📧 Email sent to: {email}")
                    return True
                except Exception as e:
                    print(f"❌ SMTP email failed: {e}")
                    return False
            else:
                print(f"❌ Form validation failed: {form.errors}")
                return False
        else:
            print("⚠️ No SMTP credentials configured - skipping SMTP test")
            
    except Exception as e:
        print(f"❌ Error during password reset test: {e}")
        return False

def show_gmail_setup_instructions():
    """Show instructions for setting up Gmail SMTP"""
    print("\n📋 GMAIL SMTP SETUP INSTRUCTIONS")
    print("=" * 50)
    print("""
🔧 TO ENABLE EMAIL SENDING WITH GMAIL:

1. CREATE APP PASSWORD:
   - Go to: https://myaccount.google.com/security
   - Enable 2-Factor Authentication (if not already enabled)
   - Go to "App passwords"
   - Generate password for "Mail"
   - Copy the 16-character password

2. CREATE .env FILE:
   Create a file named '.env' in your project root with:
   
   EMAIL_HOST_USER=your-gmail@gmail.com
   EMAIL_HOST_PASSWORD=your-16-char-app-password
   DEFAULT_FROM_EMAIL=your-gmail@gmail.com

3. RESTART DJANGO SERVER:
   - Stop current server (Ctrl+C)
   - Run: python manage.py runserver

4. TEST AGAIN:
   - Try password reset from login page
   - Check your email inbox (including spam folder)

⚠️ IMPORTANT NOTES:
- Use Gmail App Password, NOT your regular Gmail password
- Never commit .env file to version control
- Check spam folder if email doesn't arrive
- Gmail may block emails if sent too frequently
""")

def diagnose_email_issues():
    """Diagnose common email issues"""
    print("\n🔍 EMAIL ISSUE DIAGNOSIS")
    print("=" * 50)
    
    issues = []
    
    # Check backend
    if 'console' in settings.EMAIL_BACKEND.lower():
        issues.append("❌ Email backend set to console - emails won't be sent")
    
    # Check credentials
    if not settings.EMAIL_HOST_USER:
        issues.append("❌ EMAIL_HOST_USER not configured")
    
    if not settings.EMAIL_HOST_PASSWORD:
        issues.append("❌ EMAIL_HOST_PASSWORD not configured")
    
    # Check .env file
    env_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')
    if not os.path.exists(env_file):
        issues.append("❌ .env file not found")
    
    if issues:
        print("🚨 ISSUES FOUND:")
        for issue in issues:
            print(f"   {issue}")
        print("\n💡 SOLUTION: Follow Gmail setup instructions above")
    else:
        print("✅ Email configuration looks good!")
        print("💡 If still not receiving emails, check:")
        print("   - Spam/Junk folder")
        print("   - Gmail security settings")
        print("   - Server logs for errors")

if __name__ == "__main__":
    print("🚀 PASSWORD RESET EMAIL DIAGNOSTIC TOOL")
    print("=" * 60)
    
    # Check current settings
    check_email_settings()
    
    # Test console email
    test_console_email()
    
    # Test password reset for available users
    users = Login.objects.all()
    if users:
        first_user = users.first()
        if first_user.email:
            test_password_reset_for_user(first_user.email)
        else:
            print(f"\n⚠️ First user ({first_user.username}) has no email address")
    
    # Diagnose issues
    diagnose_email_issues()
    
    # Show setup instructions
    show_gmail_setup_instructions()
    
    print("\n" + "=" * 60)
    print("🎯 NEXT STEPS:")
    print("1. Set up Gmail app password and .env file")
    print("2. Restart Django server") 
    print("3. Test password reset from login page")
    print("4. Check email inbox (and spam folder)")
