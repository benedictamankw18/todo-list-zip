#!/usr/bin/env python
"""
Simple test for multipart email functionality
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from django.template.loader import render_to_string
from django.core.mail import EmailMultiAlternatives
from django.conf import settings
from Login.models import Login

def test_multipart_email():
    """Test sending proper multipart email (HTML + plain text)"""
    print("📨 TESTING MULTIPART EMAIL FOR PASSWORD RESET")
    print("=" * 60)
    
    # Get test user
    user = Login.objects.filter(email='benedictamankwa18@gmail.com').first()
    if not user:
        print("❌ User with email benedictamankwa18@gmail.com not found")
        return False
    
    print(f"👤 User found: {user.username} ({user.email})")
    
    # Create context for templates
    from django.utils.http import urlsafe_base64_encode
    from django.utils.encoding import force_bytes
    from django.contrib.auth.tokens import default_token_generator
    
    domain = '127.0.0.1:8000'
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = default_token_generator.make_token(user)
    
    context = {
        'user': user,
        'protocol': 'http',
        'domain': domain,
        'uid': uid,
        'token': token,
    }
    
    try:
        # Render both HTML and plain text templates
        subject = render_to_string('password_reset_subject.txt', context).strip()
        html_message = render_to_string('password_reset_email.html', context)
        text_message = render_to_string('password_reset_email.txt', context)
        
        print(f"📧 Subject: {subject}")
        print(f"📄 HTML template: {len(html_message)} characters")
        print(f"📝 Text template: {len(text_message)} characters")
        
        # Show preview of email content
        print(f"\n📋 EMAIL PREVIEW:")
        print(f"Subject: {subject}")
        print(f"From: {settings.DEFAULT_FROM_EMAIL}")
        print(f"To: {user.email}")
        print(f"Type: Multipart (HTML + Plain Text)")
        
        # Show part of HTML content
        print(f"\n🎨 HTML VERSION (first 200 chars):")
        print(html_message[:200] + "..." if len(html_message) > 200 else html_message)
        
        # Show part of text content
        print(f"\n📝 TEXT VERSION:")
        print(text_message)
        
        # Create multipart email
        email = EmailMultiAlternatives(
            subject=subject,
            body=text_message,  # Plain text version
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[user.email],
        )
        
        # Attach HTML version
        email.attach_alternative(html_message, "text/html")
        
        print(f"\n📬 SENDING EMAIL...")
        
        # Send email
        result = email.send()
        
        if result == 1:
            print(f"✅ MULTIPART EMAIL SENT SUCCESSFULLY!")
            print(f"🔗 Reset URL: http://127.0.0.1:8000/password-reset-confirm/{uid}/{token}/")
            print(f"📱 Email contains both HTML and plain text versions")
            print(f"📧 Check your inbox: {user.email}")
            return True
        else:
            print(f"❌ Email sending failed - no messages sent")
            return False
        
    except Exception as e:
        print(f"❌ Email sending failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def show_final_status():
    """Show final status and next steps"""
    print(f"\n🎯 FINAL STATUS REPORT")
    print("=" * 60)
    print("""
✅ IMPLEMENTED SOLUTIONS:
1. Created HTML email template (password_reset_email.html)
2. Created plain text email template (password_reset_email.txt)
3. Updated CustomPasswordResetView with proper template configuration
4. Using EmailMultiAlternatives for multipart emails

📧 EMAIL FORMAT:
- Content-Type: multipart/alternative
- Part 1: text/plain (fallback for basic email clients)
- Part 2: text/html (rich formatting for modern clients)

🧪 TESTING INSTRUCTIONS:
1. Go to: http://127.0.0.1:8000/password-reset/
2. Enter email: benedictamankwa18@gmail.com
3. Click "Reset My Password"
4. Check email inbox (and spam folder)
5. Email should display as proper UI, not HTML code

💡 IF EMAIL STILL SHOWS HTML CODE:
- Try opening email in Gmail web interface
- Check email client settings for HTML display
- Test with different email address/client
- Verify email isn't being blocked by security software

🔧 TROUBLESHOOTING:
- HTML shows instead of UI → Email client doesn't support HTML
- No email received → Check spam folder or email configuration
- Reset link doesn't work → Check token expiration (default: 3 days)
""")

if __name__ == "__main__":
    print("🚀 MULTIPART EMAIL TEST FOR PASSWORD RESET")
    print("=" * 70)
    
    # Test multipart email
    success = test_multipart_email()
    
    if success:
        print(f"\n🎉 EMAIL SYSTEM IS WORKING CORRECTLY!")
        print("📧 Multipart emails with both HTML and text versions are being sent")
        print("💡 Web interface should now send properly formatted emails")
    else:
        print(f"\n⚠️ EMAIL SYSTEM NEEDS ATTENTION")
        print("Check error messages above and email configuration")
    
    # Show final status
    show_final_status()
