from django.shortcuts import render, redirect
from .models import Task
from django.views.decorators.csrf import csrf_exempt
from rest_framework import generics
from .serializers import TaskSerializer
from django.contrib.auth.decorators import login_required
from rest_framework.permissions import IsAuthenticated

# TaskManager/views.py
# This view handles the task management functionality, allowing users to create and view tasks.
@login_required(login_url='/login/')
@csrf_exempt
def task_manager(request):
    if request.method == "POST":
        Task.objects.create(
            task=request.POST.get("task"),
            entry=request.POST.get("entry"),
            start=request.POST.get("start"),
            end=request.POST.get("end"),
            desc=request.POST.get("desc"),
            owner=request.user.username,  # Use the actual username instead of form input
            type=request.POST.get("type"),
            status=request.POST.get("status"),
        )
        return redirect('task_manager')
    # Filter tasks to show only current user's tasks
    tasks = Task.objects.filter(owner=request.user.username)
    return render(request, 'taskManager.html', {'tasks': tasks})

class TaskListCreateAPIView(generics.ListCreateAPIView):
    serializer_class = TaskSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        # Only return tasks belonging to the current user
        return Task.objects.filter(owner=self.request.user.username)
    
    def perform_create(self, serializer):
        # Automatically set the owner to the current user when creating a task
        serializer.save(owner=self.request.user.username)

class TaskRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = TaskSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        # Only allow access to tasks belonging to the current user
        return Task.objects.filter(owner=self.request.user.username)