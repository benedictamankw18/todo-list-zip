# 🔐 Django Admin Dashboard Access Guide

## 📋 Overview

The Django admin dashboard provides a powerful interface for managing your ToDoList application's data, users, and settings.

## 🌐 How to Access Admin Dashboard

### 1. **Admin URL**

```
http://127.0.0.1:8000/admin/
```

Or for production:

```
https://yourdomain.com/admin/
```

### 2. **Current Admin User**

There's already an admin user configured:

- **Username**: `n3thunt3r`
- **Status**: Staff ✅ | Superuser ✅
- **Access Level**: Full administrative access

## 🔑 Admin Access Methods

### Method 1: Use Existing Admin Account

```bash
# Login with existing admin credentials
Username: n3thunt3r
Password: [Ask the original developer for password]
```

### Method 2: Create New Superuser

```bash
# Run this command in the terminal
python manage.py createsuperuser

# Follow the prompts:
Username: your_admin_username
Email: admin@yourdomain.com
Password: your_secure_password
Password (again): your_secure_password
```

### Method 3: Make Existing User Admin

```bash
# Using Django shell
python manage.py shell

# In the shell:
from Login.models import Login
user = Login.objects.get(username='existing_username')
user.is_staff = True
user.is_superuser = True
user.save()
```

## 🛠️ Step-by-Step Access Process

### Step 1: Start the Server

```bash
python manage.py runserver
```

### Step 2: Navigate to Admin URL

Open your browser and go to:

```
http://127.0.0.1:8000/admin/
```

### Step 3: Login

- Enter your admin username and password
- Click "Log in"

### Step 4: Access Dashboard

You'll see the Django admin interface with:

- **Dashboard models** (Tasks, Social accounts, etc.)
- **Login models** (Users)
- **User management** options

## 🎯 What You Can Do in Admin Dashboard

### 👥 **User Management**

- View all registered users
- Edit user information
- Grant/revoke admin privileges
- Activate/deactivate accounts
- Reset passwords

### 📝 **Task Management**

- View all tasks across all users
- Edit task details
- Delete tasks
- Monitor task statistics
- Bulk operations

### 📱 **Social Media Management**

- View all social media accounts
- Edit social media links
- Monitor social media usage
- Delete unused accounts

### 🔧 **System Administration**

- Database management
- Site configuration
- User permissions
- Security settings

## 🔐 Security Best Practices

### ✅ **Admin Security Tips**

1. **Strong Passwords**: Use complex passwords for admin accounts
2. **Limited Access**: Only grant admin access to trusted users
3. **Regular Audits**: Periodically review admin user list
4. **Two-Factor Authentication**: Consider implementing 2FA
5. **HTTPS**: Always use HTTPS in production

### 🚨 **Important Notes**

- Admin users can access ALL user data
- Admin privileges should be granted carefully
- Regular backups are recommended
- Monitor admin activity logs

## 🛡️ User Permissions Levels

### 🔵 **Regular User**

- `is_staff = False`
- `is_superuser = False`
- Access: Only their own tasks and data

### 🟡 **Staff User**

- `is_staff = True`
- `is_superuser = False`
- Access: Admin interface with limited permissions

### 🔴 **Superuser**

- `is_staff = True`
- `is_superuser = True`
- Access: Full administrative access

## 🔧 Troubleshooting Admin Access

### ❌ **Common Issues**

#### 1. **Forgot Admin Password**

```bash
# Reset password for existing admin
python manage.py shell

from Login.models import Login
user = Login.objects.get(username='n3thunt3r')
user.set_password('new_password')
user.save()
```

#### 2. **Admin URL Not Working**

- Check if server is running
- Verify URL spelling: `/admin/`
- Check `urls.py` for admin path

#### 3. **Permission Denied**

- Verify user has `is_staff = True`
- Check if user is active
- Ensure correct username/password

#### 4. **Can't Create Superuser**

```bash
# If createsuperuser fails, try:
python manage.py shell

from Login.models import Login
user = Login.objects.create_superuser(
    username='admin',
    email='admin@example.com',
    password='secure_password'
)
```

## 📊 Admin Dashboard Features

### 🎛️ **Available Models**

- **Login** - User management
- **Task** - Task management
- **Social** - Social media accounts
- **Groups** - User groups
- **Permissions** - User permissions

### 🔍 **Admin Actions**

- Create, Read, Update, Delete (CRUD) operations
- Bulk actions (delete multiple items)
- Search and filtering
- Export data
- Import data

## 🚀 Quick Start Commands

### Create Admin User:

```bash
python manage.py createsuperuser
```

### Check Existing Admins:

```bash
python manage.py shell -c "from Login.models import Login; [print(f'{u.username}: Staff={u.is_staff}, Super={u.is_superuser}') for u in Login.objects.filter(is_staff=True)]"
```

### Reset Admin Password:

```bash
python manage.py changepassword admin_username
```

## 📞 Support

If you need help accessing the admin dashboard:

1. Check this guide first
2. Verify server is running
3. Try password reset
4. Contact system administrator

---

**Current Status**: Admin user `n3thunt3r` exists with full access  
**Admin URL**: `http://127.0.0.1:8000/admin/`  
**Security Level**: High - Superuser access available  
**Last Updated**: July 15, 2025
