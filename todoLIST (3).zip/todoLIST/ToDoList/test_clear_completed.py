#!/usr/bin/env python
"""
Test Clear Completed Tasks Functionality
Run this script to verify the API endpoint works correctly
"""

import os
import django
import requests
import json

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login
from TaskManager.models import Task
from datetime import date

def create_test_data():
    """Create test completed and incomplete tasks"""
    user = Login.objects.get(username='n3thunt3r')
    username = user.username
    
    # Create some completed tasks for testing
    test_tasks = [
        ('Test Completed Task 1', 'COMPLETE'),
        ('Test Completed Task 2', 'COMPLETE'),
        ('Test Active Task 1', 'INCOMPLETE'),
        ('Test Active Task 2', 'INCOMPLETE'),
    ]
    
    for task_name, status in test_tasks:
        Task.objects.create(
            task=task_name,
            desc=f'Test task - {status}',
            entry=date.today(),
            start=date.today(),
            end=date.today(),
            owner=username,
            type='PERSONAL',
            status=status
        )
    
    print(f"✅ Created test data for user: {username}")

def check_task_counts(username):
    """Check current task counts"""
    all_tasks = Task.objects.filter(owner=username)
    completed = all_tasks.filter(status='COMPLETE')
    incomplete = all_tasks.filter(status='INCOMPLETE')
    
    return {
        'total': all_tasks.count(),
        'completed': completed.count(),
        'incomplete': incomplete.count()
    }

def main():
    print("🧪 CLEAR COMPLETED TASKS - INTEGRATION TEST")
    print("=" * 50)
    
    # Get user
    try:
        user = Login.objects.get(username='n3thunt3r')
        username = user.username
        print(f"👤 Testing with user: {username}")
    except Login.DoesNotExist:
        print("❌ Test user 'n3thunt3r' not found")
        return
    
    # Create test data
    create_test_data()
    
    # Check before
    before = check_task_counts(username)
    print(f"\n📊 BEFORE clearing:")
    print(f"   Total: {before['total']}")
    print(f"   Completed: {before['completed']}")
    print(f"   Incomplete: {before['incomplete']}")
    
    # Simulate API call (testing the view logic directly)
    print(f"\n🔄 Testing clear completed logic...")
    
    # Import and test the view function directly
    from Dashboard.views import clear_completed_tasks
    from django.http import HttpRequest
    from django.contrib.auth.models import AnonymousUser
    
    # Create mock request
    request = HttpRequest()
    request.method = 'POST'
    request.user = user
    
    # Call the view function
    response = clear_completed_tasks(request)
    
    # Parse response
    response_data = json.loads(response.content.decode())
    print(f"📤 API Response: {response_data}")
    
    # Check after
    after = check_task_counts(username)
    print(f"\n📊 AFTER clearing:")
    print(f"   Total: {after['total']}")
    print(f"   Completed: {after['completed']}")
    print(f"   Incomplete: {after['incomplete']}")
    
    # Verify results
    if response_data.get('success') and after['completed'] == 0:
        print(f"\n🎉 SUCCESS!")
        print(f"✅ Clear completed tasks is working perfectly!")
        print(f"✅ Cleared {before['completed']} completed tasks")
        print(f"✅ Preserved {after['incomplete']} incomplete tasks")
    else:
        print(f"\n❌ FAILED!")
        print(f"Response: {response_data}")

if __name__ == "__main__":
    main()
