#!/usr/bin/env python3
"""
Visual demonstration of WhatsApp social account functionality
"""

import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login as User
from Dashboard.models import Social

def create_whatsapp_demo():
    """Create a demonstration of WhatsApp social accounts"""
    
    print("🎨 Creating WhatsApp Social Account Demo...")
    
    # Get test user
    user = User.objects.filter(username='testuser').first()
    if not user:
        print("❌ Test user 'testuser' not found")
        return
    
    # Clean up existing social accounts
    Social.objects.filter(user=user).delete()
    
    # Create diverse social accounts including WhatsApp
    social_accounts = [
        {
            'name': 'FACEBOOK',
            'url': 'https://facebook.com/testuser',
            'icon': 'fab fa-facebook'
        },
        {
            'name': 'TWITTER',
            'url': 'https://twitter.com/testuser',
            'icon': 'fab fa-twitter'
        },
        {
            'name': 'INSTAGRAM',
            'url': 'https://instagram.com/testuser',
            'icon': 'fab fa-instagram'
        },
        {
            'name': 'WHATSAPP',
            'url': 'https://wa.me/1234567890',
            'icon': 'fab fa-whatsapp'
        },
        {
            'name': 'LINKEDIN',
            'url': 'https://linkedin.com/in/testuser',
            'icon': 'fab fa-linkedin'
        },
        {
            'name': 'YOUTUBE',
            'url': 'https://youtube.com/c/testuser',
            'icon': 'fab fa-youtube'
        }
    ]
    
    print(f"\n📱 Creating social accounts for {user.username}:")
    print("=" * 60)
    
    for account in social_accounts:
        social = Social.objects.create(
            user=user,
            name=account['name'],
            url=account['url'],
            icon=account['icon']
        )
        
        # Special formatting for WhatsApp
        if account['name'] == 'WHATSAPP':
            print(f"🟢 {account['name']:<12} | {account['url']:<30} | {account['icon']}")
        else:
            print(f"📱 {account['name']:<12} | {account['url']:<30} | {account['icon']}")
    
    print("=" * 60)
    print(f"✅ Created {len(social_accounts)} social accounts")
    print(f"🟢 WhatsApp is now available as a social platform!")
    
    # Show how it would appear in the UI
    print(f"\n🎯 How WhatsApp appears in the settings page:")
    print("=" * 60)
    
    whatsapp_social = Social.objects.filter(user=user, name='WHATSAPP').first()
    if whatsapp_social:
        print(f"Platform: {whatsapp_social.name}")
        print(f"URL: {whatsapp_social.url}")
        print(f"Icon: {whatsapp_social.icon}")
        print(f"User: {whatsapp_social.user.username}")
        
        # Show HTML representation
        print(f"\n📄 HTML representation:")
        print(f'<div class="setting-item social-item" data-social-id="{whatsapp_social.id}">')
        print(f'  <div class="setting-info">')
        print(f'    <div class="setting-icon">')
        print(f'      <i class="{whatsapp_social.icon}"></i>')
        print(f'      {whatsapp_social.name}')
        print(f'    </div>')
        print(f'    <div class="setting-description">{whatsapp_social.url}</div>')
        print(f'  </div>')
        print(f'</div>')
    
    print("=" * 60)
    print("🎉 WhatsApp integration demo complete!")
    print("📱 Users can now add WhatsApp from the dropdown menu")
    print("✅ All CRUD operations (Create, Read, Update, Delete) are supported")
    print("🔒 User isolation is enforced for privacy")

if __name__ == "__main__":
    create_whatsapp_demo()
