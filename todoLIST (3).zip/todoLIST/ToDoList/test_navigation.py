#!/usr/bin/env python
"""
Test that footer links on welcome page are working correctly
"""
import requests
from bs4 import BeautifulSoup
import sys

def test_footer_links():
    """Test that all footer links on welcome page work correctly"""
    print("🔗 TESTING FOOTER LINKS")
    print("=" * 50)
    
    base_url = "http://127.0.0.1:8000"
    
    try:
        # Get the welcome page
        response = requests.get(base_url, timeout=5)
        if response.status_code != 200:
            print(f"❌ Cannot access welcome page: {response.status_code}")
            return False
        
        # Parse HTML
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Find footer links
        footer = soup.find('footer', class_='footer')
        if not footer:
            print("❌ Footer not found on welcome page")
            return False
        
        footer_links = footer.find_all('a')
        if len(footer_links) < 4:
            print(f"❌ Expected 4 footer links, found {len(footer_links)}")
            return False
        
        print(f"✅ Found {len(footer_links)} footer links")
        
        # Test each footer link
        link_tests = [
            ("Privacy Policy", "/privacy-policy/"),
            ("Terms of Service", "/terms-of-service/"), 
            ("Support", "/support/"),
            ("Contact", "/contact/")
        ]
        
        success_count = 0
        for i, (expected_text, expected_path) in enumerate(link_tests):
            if i < len(footer_links):
                link = footer_links[i]
                link_text = link.get_text().strip()
                link_href = link.get('href', '')
                
                if expected_text in link_text and expected_path in link_href:
                    # Test if the actual page loads
                    full_url = base_url + expected_path
                    try:
                        page_response = requests.get(full_url, timeout=5)
                        if page_response.status_code == 200:
                            print(f"✅ {expected_text}: Working perfectly!")
                            success_count += 1
                        else:
                            print(f"❌ {expected_text}: Page error {page_response.status_code}")
                    except Exception as e:
                        print(f"❌ {expected_text}: Connection error - {e}")
                else:
                    print(f"❌ {expected_text}: Link mismatch - text:'{link_text}', href:'{link_href}'")
            else:
                print(f"❌ {expected_text}: Link not found")
        
        print("\n" + "=" * 50)
        print(f"📊 RESULTS: {success_count}/4 footer links working")
        
        if success_count == 4:
            print("🎉 ALL FOOTER LINKS ARE WORKING PERFECTLY!")
            print("\n🔗 AVAILABLE LINKS FROM WELCOME PAGE:")
            for text, path in link_tests:
                print(f"   • {text}: {base_url}{path}")
            
            print(f"\n✨ NAVIGATION FEATURES:")
            print(f"   🏠 Welcome page footer now has working links")
            print(f"   🔗 Direct navigation to all legal/support pages")
            print(f"   📱 Consistent footer across the application")
            print(f"   🎯 Professional user experience")
            
            return True
        else:
            print("⚠️ Some footer links need attention!")
            return False
            
    except Exception as e:
        print(f"❌ Error testing footer links: {e}")
        return False

def test_page_cross_navigation():
    """Test that pages link back to each other correctly"""
    print(f"\n🔄 TESTING CROSS-PAGE NAVIGATION")
    print("=" * 50)
    
    base_url = "http://127.0.0.1:8000"
    pages_to_test = [
        ("/privacy-policy/", "Privacy Policy"),
        ("/terms-of-service/", "Terms of Service"),
        ("/support/", "Support Center"),
        ("/contact/", "Contact Us")
    ]
    
    success_count = 0
    for path, page_name in pages_to_test:
        try:
            response = requests.get(base_url + path, timeout=5)
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                nav_buttons = soup.find_all('a', class_='btn')
                
                if nav_buttons:
                    print(f"✅ {page_name}: Has {len(nav_buttons)} navigation buttons")
                    success_count += 1
                else:
                    print(f"⚠️ {page_name}: No navigation buttons found")
            else:
                print(f"❌ {page_name}: Cannot access page ({response.status_code})")
        except Exception as e:
            print(f"❌ {page_name}: Error - {e}")
    
    print(f"\n📊 Cross-navigation: {success_count}/{len(pages_to_test)} pages have navigation")
    return success_count == len(pages_to_test)

if __name__ == "__main__":
    print("🚀 TESTING COMPLETE NAVIGATION SYSTEM")
    print("=" * 70)
    
    # Test footer links
    footer_ok = test_footer_links()
    
    # Test cross-page navigation
    nav_ok = test_page_cross_navigation()
    
    if footer_ok and nav_ok:
        print(f"\n🎉 COMPLETE SUCCESS!")
        print("=" * 50)
        print("✅ Footer links work perfectly")
        print("✅ Cross-page navigation functional")
        print("✅ All pages accessible")
        print("✅ Professional navigation system complete")
        sys.exit(0)
    else:
        print(f"\n⚠️ NAVIGATION SYSTEM NEEDS ATTENTION")
        sys.exit(1)
