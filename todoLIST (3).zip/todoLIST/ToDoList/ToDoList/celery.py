#!/usr/bin/env python3
"""
Celery Configuration for Django TODO App
This enables background task processing for automatic notifications
"""

import os
from celery import Celery
from django.conf import settings

# Set the default Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')

# Create Celery app
app = Celery('todolist')

# Configure Celery using Django settings
app.config_from_object('django.conf:settings', namespace='CELERY')

# Auto-discover tasks from all installed apps
app.autodiscover_tasks()

# Celery beat schedule for periodic tasks
app.conf.beat_schedule = {
    'send-task-notifications': {
        'task': 'Dashboard.tasks.send_task_notifications',
        'schedule': 900.0,  # Every 15 minutes
        'options': {'queue': 'notifications'},
    },
    'send-daily-summary': {
        'task': 'Dashboard.tasks.send_daily_summary',
        'schedule': 28800.0,  # Every 8 hours
        'options': {'queue': 'notifications'},
    },
}

# Timezone configuration
app.conf.timezone = 'UTC'

# Task routing
app.conf.task_routes = {
    'Dashboard.tasks.send_task_notifications': {'queue': 'notifications'},
    'Dashboard.tasks.send_daily_summary': {'queue': 'notifications'},
    'Dashboard.tasks.send_individual_notification': {'queue': 'notifications'},
}

# Redis configuration (if using Redis)
app.conf.broker_url = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
app.conf.result_backend = os.getenv('REDIS_URL', 'redis://localhost:6379/0')

# Task serialization
app.conf.task_serializer = 'json'
app.conf.result_serializer = 'json'
app.conf.accept_content = ['json']

# Task result expiration
app.conf.result_expires = 3600  # 1 hour

# Worker configuration
app.conf.worker_hijack_root_logger = False
app.conf.worker_log_format = '[%(asctime)s: %(levelname)s/%(processName)s] %(message)s'
app.conf.worker_task_log_format = '[%(asctime)s: %(levelname)s/%(processName)s][%(task_name)s(%(task_id)s)] %(message)s'

@app.task(bind=True)
def debug_task(self):
    """Debug task for testing Celery setup"""
    print(f'Request: {self.request!r}')
    return f'Celery is working! Task ID: {self.request.id}'
