from django import forms
from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from TaskManager.models import Task

# Create your models here.

class Social(models.Model):
    name = models.CharField(max_length=50)
    url = models.URLField()
    icon = models.CharField(max_length=100, blank=True)  # Optional: FontAwesome class or image path
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='social_accounts')

    def __str__(self):
        return f"{self.name} - {self.user.username}"

class NotificationPreference(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notification_preference')
    
    # Contact Information
    notification_email = models.EmailField(blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    
    # Notification Types
    email_notifications = models.BooleanField(default=True)  # Enable by default
    sms_notifications = models.BooleanField(default=False)   # Disabled due to country restrictions
    whatsapp_notifications = models.BooleanField(default=True)  # Enable by default (preferred)
    
    # Notification Timing
    task_start_notifications = models.BooleanField(default=True)
    task_due_notifications = models.BooleanField(default=True)
    notification_timing_minutes = models.IntegerField(default=60)  # Minutes before due
    daily_summary = models.BooleanField(default=False)
    
    # App Preferences
    theme = models.CharField(max_length=10, default='light')
    compact_view = models.BooleanField(default=False)
    show_completed = models.BooleanField(default=True)
    default_duration_days = models.IntegerField(default=7)
    auto_archive = models.BooleanField(default=False)
    priority_colors = models.BooleanField(default=True)
    session_timeout_minutes = models.IntegerField(default=60)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Notification Preferences for {self.user.username}"

    def save(self, *args, **kwargs):
        """Override save to automatically sync notification_email with user.email"""
        # If notification_email is empty, use user's email
        if not self.notification_email and self.user and self.user.email:
            self.notification_email = self.user.email
        
        # If notification_email is provided and different from user.email, update user.email
        elif self.notification_email and self.user and self.notification_email != self.user.email:
            self.user.email = self.notification_email
            self.user.save()
        
        super().save(*args, **kwargs)
    
    def sync_email_with_user(self):
        """Manually sync notification_email with user.email"""
        if self.user and self.user.email:
            self.notification_email = self.user.email
            self.save()
    
    def update_user_email(self, new_email):
        """Update both notification_email and user.email"""
        if self.user:
            self.user.email = new_email
            self.user.save()
            self.notification_email = new_email
            self.save()
    
    @property
    def effective_email(self):
        """Get the effective email address for notifications"""
        return self.notification_email or (self.user.email if self.user else None)

class NotificationLog(models.Model):
    NOTIFICATION_TYPES = [
        ('EMAIL', 'Email'),
        ('SMS', 'SMS'),
        ('WHATSAPP', 'WhatsApp'),
    ]
    
    NOTIFICATION_STATUS = [
        ('PENDING', 'Pending'),
        ('SENT', 'Sent'),
        ('FAILED', 'Failed'),
    ]
    
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    task_id = models.IntegerField()
    notification_type = models.CharField(max_length=10, choices=NOTIFICATION_TYPES)
    message = models.TextField()
    status = models.CharField(max_length=10, choices=NOTIFICATION_STATUS, default='PENDING')
    sent_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.notification_type} notification for {self.user.username} - Task {self.task_id}"
