from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.db.models import Count, Q
from django.utils import timezone
from datetime import datetime, timedelta
from TaskManager.models import Task
from Dashboard.models import NotificationLog, NotificationPreference
from django.contrib.auth import get_user_model

User = get_user_model()

@login_required
def statistics_view(request):
    """Main statistics dashboard view"""
    user = request.user
    
    # Get basic task statistics
    total_tasks = Task.objects.filter(owner=user.username).count()
    completed_tasks = Task.objects.filter(owner=user.username, status='COMPLETE').count()
    incomplete_tasks = Task.objects.filter(owner=user.username, status='INCOMPLETE').count()
    
    # Calculate completion rate
    completion_rate = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
    
    # Get recent activity (last 30 days)
    thirty_days_ago = timezone.now().date() - timedelta(days=30)
    recent_tasks = Task.objects.filter(
        owner=user.username,
        entry__gte=thirty_days_ago
    ).count()
    
    # Get overdue tasks
    today = timezone.now().date()
    overdue_tasks = Task.objects.filter(
        owner=user.username,
        status='INCOMPLETE',
        end__lt=today
    ).count()
    
    # Get tasks by priority and type
    task_types = Task.objects.filter(owner=user.username).values('type').annotate(count=Count('type'))
    
    # Get notification statistics
    try:
        notification_prefs = NotificationPreference.objects.get(user=user)
        total_notifications = NotificationLog.objects.filter(user=user).count()
        successful_notifications = NotificationLog.objects.filter(user=user, status='SENT').count()
        failed_notifications = NotificationLog.objects.filter(user=user, status='FAILED').count()
    except NotificationPreference.DoesNotExist:
        total_notifications = 0
        successful_notifications = 0
        failed_notifications = 0
    
    context = {
        'total_tasks': total_tasks,
        'completed_tasks': completed_tasks,
        'incomplete_tasks': incomplete_tasks,
        'completion_rate': round(completion_rate, 1),
        'recent_tasks': recent_tasks,
        'overdue_tasks': overdue_tasks,
        'task_types': task_types,
        'total_notifications': total_notifications,
        'successful_notifications': successful_notifications,
        'failed_notifications': failed_notifications,
    }
    
    return render(request, 'statistics/dashboard.html', context)

@login_required
def task_analytics_api(request):
    """API endpoint for task analytics data"""
    user = request.user
    
    # Get tasks created over the last 12 months
    twelve_months_ago = timezone.now().date() - timedelta(days=365)
    
    # Monthly task creation data
    monthly_data = []
    for i in range(12):
        month_start = timezone.now().date().replace(day=1) - timedelta(days=30*i)
        month_end = (month_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        
        month_tasks = Task.objects.filter(
            owner=user.username,
            entry__gte=month_start,
            entry__lte=month_end
        ).count()
        
        monthly_data.append({
            'month': month_start.strftime('%b %Y'),
            'tasks': month_tasks
        })
    
    monthly_data.reverse()  # Show oldest to newest
    
    # Weekly productivity data (last 8 weeks)
    weekly_data = []
    for i in range(8):
        # Calculate the start of the week (Monday)
        today = timezone.now().date()
        days_since_monday = today.weekday()  # 0 = Monday, 6 = Sunday
        current_week_start = today - timedelta(days=days_since_monday)
        week_start = current_week_start - timedelta(weeks=i)
        week_end = week_start + timedelta(days=6)  # Sunday
        
        week_completed = Task.objects.filter(
            owner=user.username,
            status='COMPLETE',
            entry__gte=week_start,
            entry__lte=week_end
        ).count()
        
        week_created = Task.objects.filter(
            owner=user.username,
            entry__gte=week_start,
            entry__lte=week_end
        ).count()
        
        weekly_data.append({
            'week': week_start.strftime('Week of %b %d'),
            'completed': week_completed,
            'created': week_created
        })
    
    weekly_data.reverse()
    
    # Task status distribution
    status_data = [
        {
            'status': 'Completed',
            'count': Task.objects.filter(owner=user.username, status='COMPLETE').count(),
            'color': '#28a745'
        },
        {
            'status': 'In Progress', 
            'count': Task.objects.filter(owner=user.username, status='INCOMPLETE').count(),
            'color': '#ffc107'
        },
        {
            'status': 'Overdue',
            'count': Task.objects.filter(
                owner=user.username, 
                status='INCOMPLETE',
                end__lt=timezone.now().date()
            ).count(),
            'color': '#dc3545'
        }
    ]
    
    # Task type distribution
    type_data = []
    for task_type in Task.objects.filter(owner=user.username).values('type').distinct():
        count = Task.objects.filter(owner=user.username, type=task_type['type']).count()
        type_data.append({
            'type': task_type['type'],
            'count': count
        })
    
    return JsonResponse({
        'monthly_tasks': monthly_data,
        'weekly_productivity': weekly_data,
        'status_distribution': status_data,
        'type_distribution': type_data
    })

@login_required  
def notification_analytics_api(request):
    """API endpoint for notification analytics"""
    user = request.user
    
    # Daily notification counts (last 30 days)
    thirty_days_ago = timezone.now().date() - timedelta(days=30)
    daily_notifications = []
    
    for i in range(30):
        day = timezone.now().date() - timedelta(days=i)
        day_count = NotificationLog.objects.filter(
            user=user,
            created_at__date=day
        ).count()
        
        daily_notifications.append({
            'date': day.strftime('%m/%d'),
            'count': day_count
        })
    
    daily_notifications.reverse()
    
    # Notification success rate by channel
    channels = ['EMAIL', 'SMS', 'WHATSAPP']
    channel_stats = []
    
    for channel in channels:
        sent = NotificationLog.objects.filter(
            user=user,
            notification_type__icontains=channel,
            status='SENT'
        ).count()
        
        failed = NotificationLog.objects.filter(
            user=user,
            notification_type__icontains=channel,
            status='FAILED'
        ).count()
        
        total = sent + failed
        success_rate = (sent / total * 100) if total > 0 else 0
        
        channel_stats.append({
            'channel': channel,
            'sent': sent,
            'failed': failed,
            'success_rate': round(success_rate, 1)
        })
    
    return JsonResponse({
        'daily_notifications': daily_notifications,
        'channel_stats': channel_stats
    })
