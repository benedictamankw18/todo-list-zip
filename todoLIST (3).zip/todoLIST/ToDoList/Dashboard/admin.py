from django.contrib import admin
from .models import Social, NotificationPreference, NotificationLog

admin.site.register(Social)

@admin.register(NotificationPreference)
class NotificationPreferenceAdmin(admin.ModelAdmin):
    list_display = ['user', 'email_notifications', 'sms_notifications', 'whatsapp_notifications', 'created_at']
    list_filter = ['email_notifications', 'sms_notifications', 'whatsapp_notifications', 'daily_summary']
    search_fields = ['user__username', 'notification_email', 'phone_number']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('User', {
            'fields': ('user',)
        }),
        ('Contact Information', {
            'fields': ('notification_email', 'phone_number')
        }),
        ('Notification Types', {
            'fields': ('email_notifications', 'sms_notifications', 'whatsapp_notifications')
        }),
        ('Notification Timing', {
            'fields': ('task_start_notifications', 'task_due_notifications', 'notification_timing_minutes', 'daily_summary')
        }),
        ('App Preferences', {
            'fields': ('theme', 'compact_view', 'show_completed', 'default_duration_days', 'auto_archive', 'priority_colors', 'session_timeout_minutes')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(NotificationLog)
class NotificationLogAdmin(admin.ModelAdmin):
    list_display = ['user', 'task_id', 'notification_type', 'status', 'created_at']
    list_filter = ['notification_type', 'status', 'created_at']
    search_fields = ['user__username', 'message']
    readonly_fields = ['created_at', 'sent_at']
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Notification Details', {
            'fields': ('user', 'task_id', 'notification_type', 'message')
        }),
        ('Status', {
            'fields': ('status', 'error_message', 'sent_at')
        }),
        ('Timestamps', {
            'fields': ('created_at',)
        }),
    )
    
    def has_add_permission(self, request):
        # Prevent manual creation of logs through admin
        return False
