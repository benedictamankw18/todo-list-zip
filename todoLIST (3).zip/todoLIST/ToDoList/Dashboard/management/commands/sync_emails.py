"""
Django management command to sync email addresses between Login users and NotificationPreferences
"""
from django.core.management.base import BaseCommand
from django.conf import settings
from Dashboard.models import NotificationPreference

class Command(BaseCommand):
    help = 'Sync email addresses between Login users and NotificationPreferences'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be changed without making actual changes',
        )
        parser.add_argument(
            '--direction',
            choices=['user-to-notification', 'notification-to-user', 'both'],
            default='both',
            help='Direction of sync: user email to notification, notification to user, or both',
        )

    def handle(self, *args, **options):
        dry_run = options['dry_run']
        direction = options['direction']
        
        self.stdout.write(
            self.style.SUCCESS(
                f"🔄 Email Sync Tool - Direction: {direction}" + 
                (" (DRY RUN)" if dry_run else "")
            )
        )
        self.stdout.write("=" * 60)
        
        # Get User model
        User = settings.AUTH_USER_MODEL
        from django.apps import apps
        UserModel = apps.get_model(User)
        
        users_updated = 0
        preferences_updated = 0
        preferences_created = 0
        
        # Process all users
        for user in UserModel.objects.all():
            try:
                # Get or create notification preference
                pref, created = NotificationPreference.objects.get_or_create(
                    user=user,
                    defaults={
                        'notification_email': user.email,
                        'email_notifications': True,
                        'whatsapp_notifications': True,
                        'task_due_notifications': True,
                    }
                )
                
                if created:
                    preferences_created += 1
                    self.stdout.write(
                        self.style.SUCCESS(
                            f"✅ Created notification preferences for {user.username} with email {user.email}"
                        )
                    )
                    continue
                
                # Check for mismatched emails
                user_email = user.email or ""
                notification_email = pref.notification_email or ""
                
                if user_email != notification_email:
                    if direction in ['user-to-notification', 'both']:
                        # Sync user email to notification preference
                        if user_email:
                            self.stdout.write(
                                f"📧 {user.username}: User email '{user_email}' → Notification email '{notification_email}'"
                            )
                            if not dry_run:
                                pref.notification_email = user_email
                                pref.save()
                            preferences_updated += 1
                    
                    elif direction in ['notification-to-user', 'both']:
                        # Sync notification email to user
                        if notification_email and direction == 'notification-to-user':
                            self.stdout.write(
                                f"👤 {user.username}: Notification email '{notification_email}' → User email '{user_email}'"
                            )
                            if not dry_run:
                                user.email = notification_email
                                user.save()
                            users_updated += 1
                else:
                    self.stdout.write(
                        f"✅ {user.username}: Emails already synced ({user_email})"
                    )
                        
            except Exception as e:
                self.stdout.write(
                    self.style.ERROR(f"❌ Error processing {user.username}: {e}")
                )
        
        # Summary
        self.stdout.write("\n" + "=" * 60)
        self.stdout.write(self.style.SUCCESS("📊 SYNC SUMMARY:"))
        self.stdout.write(f"   🆕 Notification preferences created: {preferences_created}")
        self.stdout.write(f"   📧 Notification emails updated: {preferences_updated}")
        self.stdout.write(f"   👤 User emails updated: {users_updated}")
        
        if dry_run:
            self.stdout.write(
                self.style.WARNING("\n💡 This was a dry run. Use --no-dry-run to apply changes.")
            )
        else:
            self.stdout.write(
                self.style.SUCCESS("\n✅ Email synchronization completed!")
            )
        
        # Show current status
        self.stdout.write("\n" + "=" * 60)
        self.stdout.write(self.style.SUCCESS("📋 CURRENT EMAIL STATUS:"))
        
        for user in UserModel.objects.all()[:5]:  # Show first 5 users
            try:
                pref = NotificationPreference.objects.get(user=user)
                user_email = user.email or "None"
                notif_email = pref.notification_email or "None"
                status = "✅" if user_email == notif_email else "⚠️"
                self.stdout.write(f"   {status} {user.username}: User={user_email} | Notification={notif_email}")
            except NotificationPreference.DoesNotExist:
                self.stdout.write(f"   ❌ {user.username}: No notification preferences")
