#!/usr/bin/env python
"""
Test script to verify all new pages are working correctly
"""
import requests
import sys

def test_page(url, page_name):
    """Test if a page loads successfully"""
    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            print(f"✅ {page_name}: Working perfectly! ({response.status_code})")
            return True
        else:
            print(f"❌ {page_name}: Error {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ {page_name}: Connection error - {e}")
        return False

def main():
    print("🚀 TESTING NEW PAGES")
    print("=" * 50)
    
    base_url = "http://127.0.0.1:8000"
    
    # Define pages to test
    pages = [
        (f"{base_url}/privacy-policy/", "Privacy Policy"),
        (f"{base_url}/terms-of-service/", "Terms of Service"),
        (f"{base_url}/support/", "Support Center"),
        (f"{base_url}/contact/", "Contact Us"),
        (f"{base_url}/", "Welcome Page"),
    ]
    
    success_count = 0
    total_pages = len(pages)
    
    for url, name in pages:
        if test_page(url, name):
            success_count += 1
    
    print("\n" + "=" * 50)
    print(f"📊 RESULTS: {success_count}/{total_pages} pages working")
    
    if success_count == total_pages:
        print("🎉 ALL PAGES ARE WORKING PERFECTLY!")
        print("\n📋 AVAILABLE PAGES:")
        for url, name in pages:
            print(f"   • {name}: {url}")
        
        print(f"\n✨ FEATURES INCLUDED:")
        print(f"   🔒 Privacy Policy - Comprehensive privacy protection info")
        print(f"   📋 Terms of Service - Legal terms and user agreements")
        print(f"   🆘 Support Center - Help docs and troubleshooting")
        print(f"   📞 Contact Us - Multiple contact methods and form")
        print(f"   📱 Responsive design - Works on all devices")
        print(f"   🎨 Beautiful UI - Modern gradient design")
        
    else:
        print("⚠️ Some pages need attention!")
    
    return success_count == total_pages

if __name__ == "__main__":
    if main():
        sys.exit(0)
    else:
        sys.exit(1)
