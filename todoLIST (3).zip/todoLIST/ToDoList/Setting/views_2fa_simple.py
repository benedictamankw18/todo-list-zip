from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib import messages
from Login.models import Login
import json
import secrets
import hashlib

@login_required
def setup_2fa(request):
    """Setup 2FA for the current user - Simplified version"""
    try:
        user = request.user
        
        # Generate a simple backup code instead of TOTP for now
        backup_codes = []
        for i in range(10):
            code = secrets.token_hex(4).upper()
            backup_codes.append(code)
        
        # Store backup codes in session (in production, use database)
        request.session['2fa_backup_codes'] = backup_codes
        request.session['2fa_enabled'] = True
        
        return JsonResponse({
            'success': True,
            'message': '2FA Setup Complete!',
            'backup_codes': backup_codes,
            'note': 'Save these backup codes in a safe place. Each can only be used once.'
        })
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
def verify_2fa_setup(request):
    """Verify 2FA setup - Simplified version"""
    if request.method == 'POST':
        try:
            # For simplified version, just confirm setup
            request.session['2fa_confirmed'] = True
            
            return JsonResponse({
                'success': True, 
                'message': '2FA has been successfully enabled for your account!'
            })
                
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def disable_2fa(request):
    """Disable 2FA for the current user"""
    if request.method == 'POST':
        try:
            # Remove 2FA from session
            request.session.pop('2fa_backup_codes', None)
            request.session.pop('2fa_enabled', None)
            request.session.pop('2fa_confirmed', None)
            
            return JsonResponse({
                'success': True, 
                'message': '2FA has been disabled for your account.'
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def get_2fa_status(request):
    """Get current 2FA status for the user"""
    is_enabled = request.session.get('2fa_enabled', False)
    return JsonResponse({
        'success': True,
        'enabled': is_enabled
    })

def verify_2fa_login(request):
    """Verify 2FA during login - Simplified version"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            code = data.get('code', '').strip().upper()
            
            # Check backup codes
            backup_codes = request.session.get('2fa_backup_codes', [])
            
            if code in backup_codes:
                # Remove used code
                backup_codes.remove(code)
                request.session['2fa_backup_codes'] = backup_codes
                
                return JsonResponse({
                    'success': True, 
                    'message': '2FA verification successful!',
                    'redirect': '/dashboard/'
                })
            else:
                return JsonResponse({'success': False, 'error': 'Invalid backup code'})
                
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})
