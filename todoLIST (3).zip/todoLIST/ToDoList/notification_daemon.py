#!/usr/bin/env python3
"""
Advanced Notification Daemon for PythonAnywhere
This script runs continuously and handles automatic notifications
"""

import os
import sys
import time
import signal
import logging
from datetime import datetime, timedelta
from pathlib import Path

# Add project path
project_path = '/home/yourusername/todolist'  # Update with your actual username
if project_path not in sys.path:
    sys.path.insert(0, project_path)

# Load environment variables
from dotenv import load_dotenv
load_dotenv('/home/yourusername/.env')  # Update with your actual username

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
import django
django.setup()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/yourusername/notification_daemon.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class NotificationDaemon:
    """Daemon for continuous notification processing"""
    
    def __init__(self):
        self.running = True
        self.last_notification_check = datetime.now()
        self.last_daily_summary = datetime.now().date()
        
        # Check intervals (in seconds)
        self.notification_interval = 900  # 15 minutes
        self.daily_summary_time = 8  # 8 AM
        
        # Set up signal handlers for graceful shutdown
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"Received signal {signum}, shutting down gracefully...")
        self.running = False
    
    def check_notifications(self):
        """Check and send task notifications"""
        try:
            from Dashboard.notification_service import NotificationService
            
            service = NotificationService()
            service.check_and_send_notifications()
            
            self.last_notification_check = datetime.now()
            logger.info("✅ Notification check completed")
            
        except Exception as e:
            logger.error(f"❌ Error in notification check: {str(e)}")
    
    def check_daily_summary(self):
        """Check and send daily summaries"""
        try:
            current_time = datetime.now()
            current_date = current_time.date()
            
            # Send daily summary at 8 AM if not sent today
            if (current_time.hour >= self.daily_summary_time and 
                current_date > self.last_daily_summary):
                
                from Dashboard.tasks import send_daily_summary
                send_daily_summary.delay()
                
                self.last_daily_summary = current_date
                logger.info("✅ Daily summary sent")
                
        except Exception as e:
            logger.error(f"❌ Error in daily summary: {str(e)}")
    
    def run(self):
        """Main daemon loop"""
        logger.info("🚀 Starting Notification Daemon...")
        logger.info(f"📅 Notification interval: {self.notification_interval} seconds")
        logger.info(f"⏰ Daily summary time: {self.daily_summary_time}:00 AM")
        
        while self.running:
            try:
                current_time = datetime.now()
                
                # Check if it's time for notifications
                time_since_last_check = (current_time - self.last_notification_check).total_seconds()
                
                if time_since_last_check >= self.notification_interval:
                    self.check_notifications()
                
                # Check daily summary
                self.check_daily_summary()
                
                # Sleep for 60 seconds before next check
                time.sleep(60)
                
            except Exception as e:
                logger.error(f"❌ Error in daemon loop: {str(e)}")
                time.sleep(60)  # Wait before retrying
        
        logger.info("🛑 Notification Daemon stopped")

def main():
    """Main function"""
    daemon = NotificationDaemon()
    daemon.run()

if __name__ == "__main__":
    main()
