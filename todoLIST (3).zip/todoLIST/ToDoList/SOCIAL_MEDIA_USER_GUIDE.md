# Social Media Integration User Guide

## Overview

The ToDoList application now supports comprehensive social media account management, including WhatsApp integration. Users can add, edit, and manage multiple social media accounts directly from the Settings page.

## Supported Platforms

### 📱 Available Social Media Platforms:

1. **Facebook** - `fab fa-facebook`
2. **Twitter** - `fab fa-twitter`
3. **Instagram** - `fab fa-instagram`
4. **LinkedIn** - `fab fa-linkedin`
5. **YouTube** - `fab fa-youtube`
6. **WhatsApp** - `fab fa-whatsapp` ⭐ **(Newly Added)**
7. **TikTok** - `fab fa-tiktok`
8. **Snapchat** - `fab fa-snapchat`
9. **Discord** - `fab fa-discord`
10. **Telegram** - `fab fa-telegram`
11. **GitHub** - `fab fa-github`
12. **Website** - `fa fa-globe`
13. **Other** - `fa fa-link`

## How to Use

### 🔧 Adding a Social Media Account

1. **Navigate to Settings**

   - Go to `/setting/` or click the Settings menu

2. **Find Social Media Section**

   - Scroll to the "Social Media Accounts" section

3. **Add New Account**

   - Click the "Add Social Account" button
   - A modal will appear

4. **Select Platform**

   - Choose from the dropdown menu (e.g., WhatsApp)
   - The icon will automatically populate

5. **Enter URL**

   - Add your social media URL
   - Examples:
     - WhatsApp: `https://wa.me/1234567890`
     - Facebook: `https://facebook.com/username`
     - Twitter: `https://twitter.com/username`

6. **Save**
   - Click "Add Account" to save

### ✏️ Editing a Social Media Account

1. **Find the Account**

   - In the Social Media Accounts section

2. **Click Edit**

   - Click the edit button (pencil icon)

3. **Modify Details**

   - Update platform, URL, or icon as needed

4. **Save Changes**
   - Click "Update Account"

### 🗑️ Deleting a Social Media Account

1. **Find the Account**

   - In the Social Media Accounts section

2. **Click Delete**

   - Click the delete button (trash icon)

3. **Confirm**
   - Confirm the deletion when prompted

## WhatsApp Integration

### 🟢 WhatsApp-Specific Features

**Supported URL Formats:**

- `https://wa.me/1234567890`
- `https://wa.me/+1234567890`
- `https://api.whatsapp.com/send?phone=1234567890`
- `https://chat.whatsapp.com/invite/ABC123`

**Use Cases:**

- **Personal WhatsApp**: `https://wa.me/1234567890`
- **WhatsApp Business**: `https://wa.me/1234567890`
- **WhatsApp Groups**: `https://chat.whatsapp.com/invite/ABC123`
- **WhatsApp with Message**: `https://wa.me/1234567890?text=Hello`

### 📱 WhatsApp Setup Examples

**Personal Account:**

```
Platform: WhatsApp
URL: https://wa.me/1234567890
Icon: fab fa-whatsapp (auto-filled)
```

**Business Account:**

```
Platform: WhatsApp
URL: https://wa.me/1234567890?text=I'm%20interested%20in%20your%20services
Icon: fab fa-whatsapp (auto-filled)
```

## Security & Privacy

### 🔒 User Data Protection

- **User Isolation**: Each user can only see their own social media accounts
- **Authentication Required**: Must be logged in to add/edit accounts
- **CSRF Protection**: All forms are protected against CSRF attacks
- **Data Validation**: URLs are validated before saving

### 🛡️ Privacy Features

- **No Data Sharing**: Social accounts are not shared between users
- **Secure Storage**: All data is stored securely in the database
- **User Control**: Users have full control over their social media data

## Technical Details

### 🔧 Database Structure

```python
class Social(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)  # Platform name
    url = models.URLField()                  # Social media URL
    icon = models.CharField(max_length=100)  # FontAwesome icon class
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
```

### 🎨 Icon System

The system uses FontAwesome icons for consistent branding:

- Icons are automatically selected based on platform
- Custom icons can be manually specified
- All icons are responsive and theme-aware

## Troubleshooting

### ❓ Common Issues

**Problem**: Icon not displaying
**Solution**: Ensure FontAwesome is loaded and the icon class is correct

**Problem**: URL validation error
**Solution**: Check that the URL includes `https://` and is properly formatted

**Problem**: Cannot see social accounts
**Solution**: Ensure you're logged in and viewing your own account

**Problem**: Platform not in dropdown
**Solution**: Contact administrator to add additional platforms

## API Endpoints

### 🔌 Available Endpoints

- `GET /setting/` - View settings page with social accounts
- `POST /setting/social/add/` - Add new social account
- `POST /setting/social/update/` - Update existing social account
- `POST /setting/social/delete/` - Delete social account

### 📡 Request Format

**Add Social Account:**

```json
{
  "name": "WHATSAPP",
  "url": "https://wa.me/1234567890",
  "icon": "fab fa-whatsapp"
}
```

**Update Social Account:**

```json
{
  "id": 1,
  "name": "WHATSAPP",
  "url": "https://wa.me/9876543210",
  "icon": "fab fa-whatsapp"
}
```

## Support

For additional support or feature requests, contact the development team or create an issue in the project repository.

---

**Last Updated**: July 15, 2025  
**Version**: 1.0  
**Status**: ✅ WhatsApp Integration Complete
