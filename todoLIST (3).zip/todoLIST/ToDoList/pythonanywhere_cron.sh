#!/bin/bash
# PythonAnywhere Cron Job Script
# This script should be run every 15 minutes via PythonAnywhere scheduled tasks

# Set environment variables
export PYTHONPATH="/home/yourusername/todolist:$PYTHONPATH"
export DJANGO_SETTINGS_MODULE="ToDoList.settings"

# Navigate to project directory
cd /home/yourusername/todolist

# Activate virtual environment
source /home/yourusername/.virtualenvs/todolist/bin/activate

# Log start time
echo "$(date): Starting notification check" >> /home/yourusername/cron_notifications.log

# Run notification check
python manage.py send_notifications >> /home/yourusername/cron_notifications.log 2>&1

# Log completion
echo "$(date): Notification check completed" >> /home/yourusername/cron_notifications.log

# Check if it's time for daily summary (run at 8 AM)
HOUR=$(date +%H)
if [ "$HOUR" -eq 8 ]; then
    echo "$(date): Running daily summary" >> /home/yourusername/cron_notifications.log
    python manage.py send_daily_summary >> /home/yourusername/cron_notifications.log 2>&1
fi

# Rotate log file if it gets too large (keep last 1000 lines)
if [ -f "/home/yourusername/cron_notifications.log" ]; then
    LINE_COUNT=$(wc -l < /home/yourusername/cron_notifications.log)
    if [ "$LINE_COUNT" -gt 1000 ]; then
        tail -n 1000 /home/yourusername/cron_notifications.log > /home/yourusername/cron_notifications.log.tmp
        mv /home/yourusername/cron_notifications.log.tmp /home/yourusername/cron_notifications.log
    fi
fi
