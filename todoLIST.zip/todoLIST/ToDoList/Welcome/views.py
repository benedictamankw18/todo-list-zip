from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def welcome(request):
    """Welcome page view - accessible without login"""
    return render(request, 'welcome.html')

@login_required(login_url='/login/')
def info(request):
    context = {
        'app_name': 'TO-DO-LIST',
        'version': '2.0.1',
        'description': 'A comprehensive task management application with advanced features',
        'features': [
            '✅ Task Management with multiple statuses',
            '📊 Statistics and Analytics Dashboard', 
            '🔔 Email, SMS, and WhatsApp Notifications',
            '🔐 Two-Factor Authentication (2FA)',
            '📅 Daily Summary Reports',
            '👤 User Profile Management',
            '🎨 Modern Responsive UI',
            '📱 Mobile-Friendly Design'
        ],
        'developer': 'N3thunt3r - n3thunt3r.social/',
        'contact_email': 'nethunterghana@gmail.com',
        'github_repo': 'https://github.com/benedictamankw18/toDo-v2.0',
        'documentation': 'https://github.com/benedictamankw18/toDo-v2.0/blob/main/README.md'
    }
    return render(request, 'info.html', context)

def privacy_policy(request):
    """Privacy Policy page view"""
    context = {
        'page_title': 'Privacy Policy',
        'last_updated': 'July 14, 2025',
        'company_name': 'ToDoList',
        'contact_email': 'nethunterghana@gmail.com'
    }
    return render(request, 'privacy_policy.html', context)

def terms_of_service(request):
    """Terms of Service page view"""
    context = {
        'page_title': 'Terms of Service',
        'last_updated': 'July 14, 2025',
        'company_name': 'ToDoList',
        'contact_email': 'nethunterghana@gmail.com'
    }
    return render(request, 'terms_of_service.html', context)

def support(request):
    """Support page view"""
    context = {
        'page_title': 'Support Center',
        'app_name': 'ToDoList',
        'version': '2.0.1',
        'contact_email': 'nethunterghana@gmail.com',
        'developer': 'N3thunt3r',
        'github_repo': 'https://github.com/benedictamankw18/toDo-v2.0'
    }
    return render(request, 'support.html', context)

def contact(request):
    """Contact page view"""
    context = {
        'page_title': 'Contact Us',
        'company_name': 'ToDoList',
        'contact_email': 'nethunterghana@gmail.com',
        'developer': 'N3thunt3r',
        'developer_social': 'n3thunt3r.social/',
        'github_repo': 'https://github.com/benedictamankw18/toDo-v2.0'
    }
    return render(request, 'contact.html', context)

