"""
Test script to verify email synchronization between Login users and NotificationPreferences
Run this after setting up the email linking functionality
"""

import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login
from Dashboard.models import NotificationPreference

def test_email_synchronization():
    """Test the email synchronization functionality"""
    print("🧪 Testing Email Synchronization")
    print("=" * 50)
    
    # Get first user for testing
    try:
        user = Login.objects.first()
        if not user:
            print("❌ No users found in database")
            return
        
        print(f"📋 Testing with user: {user.username}")
        print(f"   Current user email: {user.email}")
        
        # Get or create notification preference
        pref, created = NotificationPreference.objects.get_or_create(
            user=user,
            defaults={'notification_email': user.email}
        )
        
        if created:
            print("✅ Created new notification preferences")
        else:
            print("✅ Using existing notification preferences")
        
        print(f"   Current notification email: {pref.notification_email}")
        
        # Test 1: Update notification email and see if user email changes
        print("\n🧪 Test 1: Update notification email")
        original_user_email = user.email
        test_email = "test@example.com"
        
        print(f"   Setting notification email to: {test_email}")
        pref.notification_email = test_email
        pref.save()
        
        # Refresh user from database
        user.refresh_from_db()
        print(f"   User email after update: {user.email}")
        
        if user.email == test_email:
            print("   ✅ SUCCESS: User email was updated automatically!")
        else:
            print("   ❌ FAILED: User email was not updated")
        
        # Test 2: Update user email and see if notification email changes
        print("\n🧪 Test 2: Update user email")
        test_email_2 = "updated@example.com"
        
        print(f"   Setting user email to: {test_email_2}")
        user.email = test_email_2
        user.save()
        
        # Refresh preference from database
        pref.refresh_from_db()
        print(f"   Notification email after user update: {pref.notification_email}")
        
        if pref.notification_email == test_email_2:
            print("   ✅ SUCCESS: Notification email was updated automatically!")
        else:
            print("   ❌ FAILED: Notification email was not updated")
        
        # Test 3: Test effective_email property
        print("\n🧪 Test 3: Test effective_email property")
        effective_email = pref.effective_email
        print(f"   Effective email: {effective_email}")
        
        if effective_email == test_email_2:
            print("   ✅ SUCCESS: Effective email property works correctly!")
        else:
            print("   ❌ FAILED: Effective email property not working")
        
        # Restore original email
        print(f"\n🔄 Restoring original email: {original_user_email}")
        user.email = original_user_email
        user.save()
        
        print("\n" + "=" * 50)
        print("✅ Email synchronization test completed!")
        
    except Exception as e:
        print(f"❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()

def show_all_email_mappings():
    """Show current email mappings for all users"""
    print("\n📊 Current Email Mappings")
    print("=" * 50)
    
    users = Login.objects.all()
    for user in users:
        try:
            pref = NotificationPreference.objects.get(user=user)
            user_email = user.email or "None"
            notif_email = pref.notification_email or "None"
            sync_status = "✅ SYNCED" if user_email == notif_email else "⚠️ DIFFERENT"
            
            print(f"👤 {user.username}:")
            print(f"   User email: {user_email}")
            print(f"   Notification email: {notif_email}")
            print(f"   Status: {sync_status}")
            print()
            
        except NotificationPreference.DoesNotExist:
            print(f"👤 {user.username}:")
            print(f"   User email: {user.email or 'None'}")
            print(f"   Notification email: No preferences found")
            print(f"   Status: ❌ MISSING PREFERENCES")
            print()

if __name__ == "__main__":
    try:
        test_email_synchronization()
        show_all_email_mappings()
        
        print("\n💡 Commands to run:")
        print("1. python manage.py makemigrations Dashboard")
        print("2. python manage.py migrate")
        print("3. python manage.py sync_emails --dry-run")
        print("4. python manage.py sync_emails")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        print("Make sure Django is properly installed and the server is not running")
