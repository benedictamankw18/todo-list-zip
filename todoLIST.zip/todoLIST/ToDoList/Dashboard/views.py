from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from TaskManager.models import Task
from .models import Social, NotificationPreference
from .forms import TaskForm
import json
from datetime import datetime

@login_required(login_url='/login/')
def dashboard(request):
    if request.method == 'POST':
        # Handle task creation
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    
    # Filter tasks to show only current user's tasks
    tasks = Task.objects.filter(owner=request.user.username)
    # Filter social accounts to show only current user's social accounts
    socials = Social.objects.filter(user=request.user)
    last_login = request.user.last_login
    return render(request, 'dashboard.html', {
        'tasks': tasks,
        'socials': socials,
        'last_login': last_login,
    })

def add_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dashboard')  # or your dashboard view name
    else:
        form = TaskForm()
    return render(request, 'add_task.html', {'form': form})

@login_required(login_url='/login/')
def update_task(request, task_id):
    # Ensure the task belongs to the current user
    task = get_object_or_404(Task, id=task_id, owner=request.user.username)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    return redirect('dashboard')

@login_required(login_url='/login/')
@login_required(login_url='/login/')
def delete_task(request, task_id):
    if request.method == 'POST':
        # Ensure the task belongs to the current user
        task = get_object_or_404(Task, id=task_id, owner=request.user.username)
        task.delete()
        return JsonResponse({'success': True})
    return JsonResponse({'success': False})

@login_required(login_url='/login/')
def delete_selected_tasks(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            task_ids = data.get('task_ids', [])
            # Only delete tasks that belong to the current user
            Task.objects.filter(id__in=task_ids, owner=request.user.username).delete()
            return JsonResponse({'success': True})
        except:
            return JsonResponse({'success': False})
    return JsonResponse({'success': False})

@login_required(login_url='/login/')
def clear_all_tasks(request):
    if request.method == 'POST':
        # Only delete tasks belonging to the current user
        Task.objects.filter(owner=request.user.username).delete()
        return JsonResponse({'success': True})
    return JsonResponse({'success': False})

@login_required(login_url='/login/')
@csrf_exempt
def save_settings(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Get or create notification preferences for the user
            prefs, created = NotificationPreference.objects.get_or_create(user=request.user)
            
            # Update contact information
            prefs.notification_email = data.get('notificationEmail', '')
            prefs.phone_number = data.get('phoneNumber', '')
            
            # Update notification preferences
            prefs.email_notifications = data.get('emailNotifications', False)
            prefs.sms_notifications = data.get('smsNotifications', False)
            prefs.whatsapp_notifications = data.get('whatsappNotifications', False)
            prefs.task_start_notifications = data.get('taskStartNotifications', True)
            prefs.task_due_notifications = data.get('taskDueNotifications', True)
            prefs.notification_timing_minutes = int(data.get('notificationTiming', 60))
            prefs.daily_summary = data.get('dailySummary', False)
            
            # Update appearance preferences
            prefs.theme = data.get('theme', 'light')
            prefs.compact_view = data.get('compactView', False)
            prefs.show_completed = data.get('showCompleted', True)
            
            # Update task management preferences
            prefs.default_duration_days = int(data.get('defaultDuration', 7))
            prefs.auto_archive = data.get('autoArchive', False)
            prefs.priority_colors = data.get('priorityColors', True)
            prefs.session_timeout_minutes = int(data.get('sessionTimeout', 60))
            
            prefs.save()
            
            return JsonResponse({'success': True, 'message': 'Settings saved successfully'})
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required(login_url='/login/')
def get_settings(request):
    """Get user's notification preferences"""
    try:
        prefs = NotificationPreference.objects.get(user=request.user)
        data = {
            'notificationEmail': prefs.notification_email or '',
            'phoneNumber': prefs.phone_number or '',
            'emailNotifications': prefs.email_notifications,
            'smsNotifications': prefs.sms_notifications,
            'whatsappNotifications': prefs.whatsapp_notifications,
            'taskStartNotifications': prefs.task_start_notifications,
            'taskDueNotifications': prefs.task_due_notifications,
            'notificationTiming': prefs.notification_timing_minutes,
            'dailySummary': prefs.daily_summary,
            'theme': prefs.theme,
            'compactView': prefs.compact_view,
            'showCompleted': prefs.show_completed,
            'defaultDuration': prefs.default_duration_days,
            'autoArchive': prefs.auto_archive,
            'priorityColors': prefs.priority_colors,
            'sessionTimeout': prefs.session_timeout_minutes,
        }
        return JsonResponse({'success': True, 'settings': data})
    except NotificationPreference.DoesNotExist:
        return JsonResponse({'success': True, 'settings': {}})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})
    
@login_required(login_url='/login/')
@csrf_exempt
def clear_completed_tasks(request):
    """Clear all completed tasks for the current user"""
    if request.method == 'POST':
        try:
            # Get current user's username
            username = request.user.username
            
            # Find all completed tasks for this user
            completed_tasks = Task.objects.filter(
                owner=username,
                status='COMPLETE'
            )
            
            # Count tasks before deletion
            task_count = completed_tasks.count()
            
            if task_count == 0:
                return JsonResponse({
                    'success': False, 
                    'error': 'No completed tasks found to clear'
                })
            
            # Delete all completed tasks
            completed_tasks.delete()
            
            return JsonResponse({
                'success': True, 
                'message': f'Successfully cleared {task_count} completed task{"s" if task_count != 1 else ""}',
                'cleared_count': task_count
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required(login_url='/login/')
def export_tasks(request):
    """Export all user's tasks as JSON file for download"""
    try:
        # Get current user's username
        username = request.user.username
        
        # Get all tasks for this user
        user_tasks = Task.objects.filter(owner=username)
        
        # Prepare task data for export
        tasks_data = []
        for task in user_tasks:
            task_dict = {
                'id': task.id,
                'task': task.task,
                'description': task.desc,
                'entry_date': task.entry.strftime('%Y-%m-%d') if task.entry else None,
                'start_date': task.start.strftime('%Y-%m-%d') if task.start else None,
                'end_date': task.end.strftime('%Y-%m-%d') if task.end else None,
                'status': task.status,
                'type': task.type,
                'owner': task.owner,
                'created_at': task.entry.strftime('%Y-%m-%d %H:%M:%S') if task.entry else None
            }
            tasks_data.append(task_dict)
        
        # Create export metadata
        export_data = {
            'export_info': {
                'username': username,
                'export_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'total_tasks': len(tasks_data),
                'completed_tasks': len([t for t in tasks_data if t['status'] == 'COMPLETE']),
                'incomplete_tasks': len([t for t in tasks_data if t['status'] == 'INCOMPLETE'])
            },
            'tasks': tasks_data
        }
        
        # Convert to JSON
        json_data = json.dumps(export_data, indent=2, ensure_ascii=False)
        
        # Create HTTP response with JSON file
        response = HttpResponse(json_data, content_type='application/json')
        filename = f"todo_tasks_{username}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        
        return response
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': f'Export failed: {str(e)}'})

