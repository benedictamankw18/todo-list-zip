"""
Django signals to synchronize email between Login user and NotificationPreference
"""
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.conf import settings
from .models import NotificationPreference

@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def sync_notification_email_on_user_save(sender, instance, created, **kwargs):
    """
    When a Login user is saved, sync their email to their notification preferences
    """
    try:
        # Get or create notification preference for the user
        pref, pref_created = NotificationPreference.objects.get_or_create(
            user=instance,
            defaults={
                'notification_email': instance.email,
                'email_notifications': True,
                'whatsapp_notifications': True,
                'task_due_notifications': True,
            }
        )
        
        # If preference exists and email is different, sync it
        if not pref_created and pref.notification_email != instance.email:
            pref.notification_email = instance.email
            pref.save()
            
    except Exception as e:
        # Log error but don't break user operations
        print(f"Error syncing notification email for user {instance.username}: {e}")

@receiver(pre_save, sender=NotificationPreference)
def sync_user_email_on_preference_save(sender, instance, **kwargs):
    """
    When notification preferences are saved, sync email back to the user
    """
    try:
        # Only sync if notification_email is provided and different from user email
        if (instance.notification_email and 
            instance.user and 
            instance.notification_email != instance.user.email):
            
            # Update user email to match notification email
            instance.user.email = instance.notification_email
            instance.user.save()
            
    except Exception as e:
        # Log error but don't break the save operation
        print(f"Error syncing user email from notification preferences: {e}")
