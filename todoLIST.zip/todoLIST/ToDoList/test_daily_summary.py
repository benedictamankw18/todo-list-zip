#!/usr/bin/env python
"""
Test Daily Summary Feature
"""
import os
import sys
import django
from datetime import datetime

# Add the parent directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login as User
from TaskManager.models import Task
from Dashboard.models import NotificationPreference
from Dashboard.notification_service import NotificationService
from django.utils import timezone

def test_daily_summary():
    """Test the daily summary functionality"""
    print("🕕 Testing Daily Summary at 6 PM...")
    
    try:
        from django.contrib.auth import get_user_model
        User = get_user_model()
        
        # Get all users with daily summary enabled
        preferences = NotificationPreference.objects.filter(daily_summary=True)
        print(f"Found {preferences.count()} users with daily summary enabled")
        
        if preferences.count() == 0:
            print("❌ No users have daily summary enabled")
            print("💡 Go to http://127.0.0.1:8000/setting/ to enable it")
            return
        
        for pref in preferences:
            user = pref.user
            print(f"\n📧 Processing daily summary for user: {user.username}")
            
            # Get user's tasks for today
            today = timezone.now().date()
            tasks_due_today = Task.objects.filter(
                owner=user.username,
                end=today,
                status='INCOMPLETE'
            )
            
            tasks_starting_today = Task.objects.filter(
                owner=user.username,
                start=today,
                status='INCOMPLETE'
            )
            
            print(f"   📅 Tasks due today: {tasks_due_today.count()}")
            print(f"   🚀 Tasks starting today: {tasks_starting_today.count()}")
            
            if tasks_due_today.exists() or tasks_starting_today.exists():
                notification_service = NotificationService()
                # Create a summary message with proper formatting
                summary_message = f"Daily Summary for {today}:\n"
                
                if tasks_starting_today.exists():
                    summary_message += f"\nTasks Starting Today ({tasks_starting_today.count()}):\n"
                    for task in tasks_starting_today:
                        summary_message += f"• {task.task}\n"
                
                if tasks_due_today.exists():
                    summary_message += f"\nTasks Due Today ({tasks_due_today.count()}):\n" 
                    for task in tasks_due_today:
                        summary_message += f"• {task.task}\n"
                
                # Format for display (showing actual line breaks)
                display_message = summary_message.replace('\n', '\n   ')
                print(f"📄 Summary message:\n   {display_message}")
                
                # Actually send the notifications
                sent_channels = []
                
                if pref.email_notifications:
                    try:
                        # Send email summary
                        email = pref.notification_email or user.email
                        if email:
                            from django.core.mail import send_mail
                            from django.conf import settings
                            
                            send_mail(
                                subject=f"Daily Task Summary - {today}",
                                message=summary_message,
                                from_email=settings.DEFAULT_FROM_EMAIL,
                                recipient_list=[email],
                                fail_silently=False,
                            )
                            print("   📧 ✅ Email summary sent!")
                            sent_channels.append("Email")
                        else:
                            print("   📧 ❌ No email address configured")
                    except Exception as e:
                        print(f"   📧 ❌ Email failed: {str(e)}")
                
                if pref.whatsapp_notifications:
                    try:
                        # Send WhatsApp summary
                        phone = pref.phone_number
                        if phone:
                            # Use the notification service WhatsApp method
                            result = notification_service._send_summary_whatsapp(user, summary_message)
                            if result:
                                print("   📱 ✅ WhatsApp summary sent!")
                                sent_channels.append("WhatsApp")
                            else:
                                print("   📱 ❌ WhatsApp send failed")
                        else:
                            print("   📱 ❌ No phone number configured")
                    except Exception as e:
                        print(f"   📱 ❌ WhatsApp failed: {str(e)}")
                
                if pref.sms_notifications:
                    try:
                        # Send SMS summary
                        phone = pref.phone_number
                        if phone:
                            result = notification_service._send_summary_sms(user, summary_message)
                            if result:
                                print("   📲 ✅ SMS summary sent!")
                                sent_channels.append("SMS")
                            else:
                                print("   📲 ❌ SMS send failed")
                        else:
                            print("   📲 ❌ No phone number configured")
                    except Exception as e:
                        print(f"   📲 ❌ SMS failed: {str(e)}")
                
                if sent_channels:
                    print(f"   🎉 Daily summary sent via: {', '.join(sent_channels)}")
                else:
                    print("   ⚠️  No summary sent - check configuration")
            else:
                print("   ℹ️  No tasks for today - no summary needed")
        
        print(f"\n🎉 Daily summary test completed at {datetime.now()}")
        
    except Exception as e:
        print(f"❌ Error in daily summary: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_daily_summary()
