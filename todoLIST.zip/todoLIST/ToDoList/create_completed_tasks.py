#!/usr/bin/env python
"""
Create some completed tasks for testing the clear completed functionality
"""

import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login
from TaskManager.models import Task
from datetime import date

def create_completed_tasks():
    """Create some completed tasks for testing"""
    try:
        # Get the user
        user = Login.objects.get(username='n3thunt3r')
        username = user.username
        
        # Create some completed tasks
        completed_tasks = [
            {
                'task': 'Completed Task 1 - Test',
                'desc': 'This is a completed task for testing clear functionality',
                'status': 'COMPLETE'
            },
            {
                'task': 'Completed Task 2 - Test',
                'desc': 'Another completed task for testing',
                'status': 'COMPLETE'
            },
            {
                'task': 'Completed Task 3 - Test',
                'desc': 'Third completed task for testing',
                'status': 'COMPLETE'
            }
        ]
        
        created_count = 0
        for task_data in completed_tasks:
            task = Task.objects.create(
                task=task_data['task'],
                desc=task_data['desc'],
                entry=date.today(),
                start=date.today(),
                end=date.today(),
                owner=username,
                type='PERSONAL',
                status=task_data['status']
            )
            created_count += 1
            print(f"✅ Created completed task: {task.task}")
        
        # Show current task counts
        all_tasks = Task.objects.filter(owner=username)
        completed = all_tasks.filter(status='COMPLETE')
        incomplete = all_tasks.filter(status='INCOMPLETE')
        
        print(f"\n📊 Current task status for {username}:")
        print(f"   Total tasks: {all_tasks.count()}")
        print(f"   Completed: {completed.count()}")
        print(f"   Incomplete: {incomplete.count()}")
        
        print(f"\n🎉 Successfully created {created_count} completed tasks!")
        print("Now you can test the 'Clear Completed Tasks' functionality.")
        
    except Login.DoesNotExist:
        print("❌ User 'n3thunt3r' not found!")
    except Exception as e:
        print(f"❌ Error: {str(e)}")

if __name__ == "__main__":
    create_completed_tasks()
