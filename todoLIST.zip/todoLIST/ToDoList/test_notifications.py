#!/usr/bin/env python
"""
Test script for notification system
"""
import os
import sys
import django
from datetime import datetime, timedelta

# Add the parent directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login as User
from TaskManager.models import Task
from Dashboard.models import NotificationPreference
from Dashboard.notification_service import NotificationService

def create_test_user():
    """Create a test user if it doesn't exist"""
    username = "testuser"
    try:
        user = User.objects.get(username=username)
        print(f"User '{username}' already exists")
    except User.DoesNotExist:
        user = User.objects.create_user(
            username=username,
            email="test@example.com",
            password="testpass123"
        )
        print(f"Created user '{username}'")
    return user

def create_notification_preferences(user):
    """Create notification preferences for the test user"""
    prefs, created = NotificationPreference.objects.get_or_create(
        user=user,
        defaults={
            'notification_email': 'test@example.com',
            'phone_number': '+1234567890',
            'email_notifications': True,
            'sms_notifications': True,
            'whatsapp_notifications': True,
            'task_start_notifications': True,
            'task_due_notifications': True,
            'notification_timing_minutes': 60,
            'daily_summary': True,
        }
    )
    if created:
        print("Created notification preferences")
    else:
        print("Updated notification preferences")
    return prefs

def create_test_tasks(user):
    """Create test tasks with various due dates"""
    tasks = []
    
    # Task due in 1 hour
    task1 = Task.objects.create(
        task="Test Task - Due in 1 hour",
        entry=datetime.now().date(),
        start=datetime.now().date(),
        end=(datetime.now() + timedelta(hours=1)).date(),
        desc="This task is due in 1 hour - should trigger notification",
        owner=user.username,
        type="PERSONAL",
        status="INCOMPLETE"
    )
    tasks.append(task1)
    
    # Task starting today
    task2 = Task.objects.create(
        task="Test Task - Starting today",
        entry=datetime.now().date(),
        start=datetime.now().date(),
        end=(datetime.now() + timedelta(days=1)).date(),
        desc="This task starts today - should trigger start notification",
        owner=user.username,
        type="PERSONAL",
        status="INCOMPLETE"
    )
    tasks.append(task2)
    
    # Task due tomorrow
    task3 = Task.objects.create(
        task="Test Task - Due tomorrow",
        entry=datetime.now().date(),
        start=datetime.now().date(),
        end=(datetime.now() + timedelta(days=1)).date(),
        desc="This task is due tomorrow - should not trigger notification yet",
        owner=user.username,
        type="PERSONAL",
        status="INCOMPLETE"
    )
    tasks.append(task3)
    
    print(f"Created {len(tasks)} test tasks")
    return tasks

def test_notification_service():
    """Test the notification service"""
    print("\n=== Testing Notification Service ===")
    
    # Create test user and preferences
    user = create_test_user()
    prefs = create_notification_preferences(user)
    
    # Create test tasks
    tasks = create_test_tasks(user)
    
    # Test notification service
    notification_service = NotificationService()
    
    print("\nTesting individual notifications...")
    for task in tasks:
        print(f"\nTesting notifications for: {task.task}")
        
        # Test start notification
        results = notification_service.send_task_notification(user, task, 'start')
        print(f"Start notification results: {results}")
        
        # Test due notification
        results = notification_service.send_task_notification(user, task, 'due')
        print(f"Due notification results: {results}")
    
    print("\nTesting bulk notification check...")
    notification_service.check_and_send_notifications()
    
    print("\n=== Notification Test Complete ===")

def test_settings_endpoints():
    """Test the settings save/load endpoints"""
    print("\n=== Testing Settings Endpoints ===")
    
    user = create_test_user()
    
    # Test settings data
    test_settings = {
        'notificationEmail': 'test@example.com',
        'phoneNumber': '+1234567890',
        'emailNotifications': True,
        'smsNotifications': True,
        'whatsappNotifications': True,
        'taskStartNotifications': True,
        'taskDueNotifications': True,
        'notificationTiming': '60',
        'dailySummary': True,
        'theme': 'light',
        'compactView': False,
        'showCompleted': True,
        'defaultDuration': '7',
        'autoArchive': False,
        'priorityColors': True,
        'sessionTimeout': '60',
    }
    
    # Create notification preferences
    prefs, created = NotificationPreference.objects.get_or_create(
        user=user,
        defaults={
            'notification_email': test_settings['notificationEmail'],
            'phone_number': test_settings['phoneNumber'],
            'email_notifications': test_settings['emailNotifications'],
            'sms_notifications': test_settings['smsNotifications'],
            'whatsapp_notifications': test_settings['whatsappNotifications'],
            'task_start_notifications': test_settings['taskStartNotifications'],
            'task_due_notifications': test_settings['taskDueNotifications'],
            'notification_timing_minutes': int(test_settings['notificationTiming']),
            'daily_summary': test_settings['dailySummary'],
            'theme': test_settings['theme'],
            'compact_view': test_settings['compactView'],
            'show_completed': test_settings['showCompleted'],
            'default_duration_days': int(test_settings['defaultDuration']),
            'auto_archive': test_settings['autoArchive'],
            'priority_colors': test_settings['priorityColors'],
            'session_timeout_minutes': int(test_settings['sessionTimeout']),
        }
    )
    
    if created:
        print("Created notification preferences via code")
    else:
        # Update existing preferences
        prefs.notification_email = test_settings['notificationEmail']
        prefs.phone_number = test_settings['phoneNumber']
        prefs.email_notifications = test_settings['emailNotifications']
        prefs.sms_notifications = test_settings['smsNotifications']
        prefs.whatsapp_notifications = test_settings['whatsappNotifications']
        prefs.task_start_notifications = test_settings['taskStartNotifications']
        prefs.task_due_notifications = test_settings['taskDueNotifications']
        prefs.notification_timing_minutes = int(test_settings['notificationTiming'])
        prefs.daily_summary = test_settings['dailySummary']
        prefs.theme = test_settings['theme']
        prefs.compact_view = test_settings['compactView']
        prefs.show_completed = test_settings['showCompleted']
        prefs.default_duration_days = int(test_settings['defaultDuration'])
        prefs.auto_archive = test_settings['autoArchive']
        prefs.priority_colors = test_settings['priorityColors']
        prefs.session_timeout_minutes = int(test_settings['sessionTimeout'])
        prefs.save()
        print("Updated notification preferences via code")
    
    print(f"User: {user.username}")
    print(f"Email notifications: {prefs.email_notifications}")
    print(f"SMS notifications: {prefs.sms_notifications}")
    print(f"WhatsApp notifications: {prefs.whatsapp_notifications}")
    print(f"Notification timing: {prefs.notification_timing_minutes} minutes")
    
    print("\n=== Settings Test Complete ===")

if __name__ == "__main__":
    print("Starting notification system tests...")
    test_settings_endpoints()
    test_notification_service()
    print("\nAll tests completed!")
