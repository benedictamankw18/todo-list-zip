from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from Dashboard.models import Social
import json

# Create your views here.
@login_required(login_url='/login/')
def setting(request):
    # Get user's social accounts
    user_socials = Social.objects.filter(user=request.user)
    return render(request, 'setting.html', {'user_socials': user_socials})

@login_required(login_url='/login/')
@csrf_exempt
def add_social(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Create new social account for the current user
            social = Social.objects.create(
                name=data.get('name'),
                url=data.get('url'),
                icon=data.get('icon', 'fa fa-link'),
                user=request.user
            )
            
            return JsonResponse({
                'success': True,
                'message': 'Social account added successfully',
                'social_id': social.id
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required(login_url='/login/')
@csrf_exempt
def update_social(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            social_id = data.get('id')
            
            # Get social account belonging to current user
            social = get_object_or_404(Social, id=social_id, user=request.user)
            
            # Update fields
            social.name = data.get('name')
            social.url = data.get('url')
            social.icon = data.get('icon', 'fa fa-link')
            social.save()
            
            return JsonResponse({
                'success': True,
                'message': 'Social account updated successfully'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required(login_url='/login/')
@csrf_exempt
def delete_social(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            social_id = data.get('id')
            
            # Get social account belonging to current user
            social = get_object_or_404(Social, id=social_id, user=request.user)
            social.delete()
            
            return JsonResponse({
                'success': True,
                'message': 'Social account deleted successfully'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})