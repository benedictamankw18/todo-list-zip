#!/usr/bin/env python
"""
Test password reset with proper request context
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from django.test import RequestFactory
from django.contrib.auth.forms import PasswordResetForm
from django.conf import settings
from Login.models import Login

def test_password_reset_with_request():
    """Test password reset with proper request context"""
    print("🔐 TESTING PASSWORD RESET WITH REQUEST CONTEXT")
    print("=" * 60)
    
    # Create a mock request
    factory = RequestFactory()
    request = factory.post('/password-reset/')
    request.META['HTTP_HOST'] = '127.0.0.1:8000'
    
    # Test for each user with email
    users_with_email = Login.objects.filter(email__isnull=False).exclude(email='')
    
    for user in users_with_email:
        print(f"\n👤 Testing password reset for: {user.username} ({user.email})")
        
        try:
            form = PasswordResetForm({'email': user.email})
            if form.is_valid():
                form.save(
                    request=request,
                    use_https=False,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    email_template_name='password_reset_email.html',
                    subject_template_name='password_reset_subject.txt'
                )
                print(f"   ✅ Password reset email sent to {user.email}")
                print(f"   📧 Check the email inbox for: {user.email}")
            else:
                print(f"   ❌ Form validation failed: {form.errors}")
                
        except Exception as e:
            print(f"   ❌ Error sending password reset: {e}")
    
    print(f"\n🎯 PASSWORD RESET TEST COMPLETED!")
    print(f"📱 Check your email inboxes (and spam folders)")
    print(f"🔗 Reset links should be valid and clickable")

def test_specific_email(email):
    """Test password reset for a specific email"""
    print(f"\n🎯 TESTING SPECIFIC EMAIL: {email}")
    print("=" * 50)
    
    # Create a mock request
    factory = RequestFactory()
    request = factory.post('/password-reset/')
    request.META['HTTP_HOST'] = '127.0.0.1:8000'
    
    try:
        form = PasswordResetForm({'email': email})
        if form.is_valid():
            form.save(
                request=request,
                use_https=False,
                from_email=settings.DEFAULT_FROM_EMAIL,
                email_template_name='password_reset_email.html',
                subject_template_name='password_reset_subject.txt'
            )
            print(f"✅ Password reset email sent to: {email}")
            print(f"📧 Check your email inbox and spam folder")
            print(f"🔗 The reset link should work when clicked")
            return True
        else:
            print(f"❌ Form validation failed: {form.errors}")
            return False
            
    except Exception as e:
        print(f"❌ Error sending password reset: {e}")
        return False

if __name__ == "__main__":
    print("🚀 PASSWORD RESET EMAIL TEST WITH REQUEST CONTEXT")
    print("=" * 70)
    
    # Test password reset for all users
    test_password_reset_with_request()
    
    # Test for the specific email you're trying to reset
    print("\n" + "=" * 70)
    test_specific_email('benedictamankwa18@gmail.com')
    
    print(f"\n💡 IMPORTANT NOTES:")
    print(f"✅ Email configuration is working")
    print(f"✅ SMTP credentials are valid")
    print(f"📧 Emails should be delivered to inboxes")
    print(f"🗂️ Check spam/junk folders if not in inbox")
    print(f"🔄 Try the password reset from the web interface now")
