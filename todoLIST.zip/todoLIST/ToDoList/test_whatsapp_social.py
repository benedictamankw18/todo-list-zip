#!/usr/bin/env python3
"""
Test script to verify WhatsApp integration in social accounts
"""

import requests
import json

def test_whatsapp_social_account():
    """Test adding WhatsApp as a social platform"""
    
    # First, login to get session
    login_data = {
        'username': 'testuser',
        'password': 'testpass123'
    }
    
    session = requests.Session()
    
    try:
        # Login
        login_response = session.post('http://127.0.0.1:8000/login/', data=login_data)
        print(f"Login response status: {login_response.status_code}")
        
        # Get CSRF token from settings page
        settings_response = session.get('http://127.0.0.1:8000/setting/')
        print(f"Settings page status: {settings_response.status_code}")
        
        # Extract CSRF token
        csrf_token = None
        for line in settings_response.text.split('\n'):
            if 'csrf_token' in line and 'value' in line:
                csrf_token = line.split('value="')[1].split('"')[0]
                break
        
        if not csrf_token:
            print("❌ Could not find CSRF token")
            return
        
        print(f"✅ CSRF token found: {csrf_token[:20]}...")
        
        # Test adding WhatsApp social account
        whatsapp_data = {
            'name': 'WHATSAPP',
            'url': 'https://wa.me/1234567890',
            'icon': 'fab fa-whatsapp',
            'csrfmiddlewaretoken': csrf_token
        }
        
        headers = {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrf_token,
        }
        
        add_response = session.post(
            'http://127.0.0.1:8000/setting/social/add/',
            data=json.dumps(whatsapp_data),
            headers=headers
        )
        
        print(f"Add WhatsApp response status: {add_response.status_code}")
        
        if add_response.status_code == 200:
            response_data = add_response.json()
            print(f"✅ WhatsApp account added successfully!")
            print(f"Response: {response_data}")
            
            # Verify it appears in the settings page
            settings_check = session.get('http://127.0.0.1:8000/setting/')
            if 'WHATSAPP' in settings_check.text and 'fa-whatsapp' in settings_check.text:
                print("✅ WhatsApp appears correctly in settings page")
            else:
                print("❌ WhatsApp not found in settings page")
                
        else:
            print(f"❌ Failed to add WhatsApp: {add_response.text}")
            
    except Exception as e:
        print(f"❌ Error during test: {e}")
    
    finally:
        session.close()

if __name__ == "__main__":
    print("🧪 Testing WhatsApp social account integration...")
    test_whatsapp_social_account()
