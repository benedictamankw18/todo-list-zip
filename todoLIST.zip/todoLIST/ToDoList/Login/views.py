from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import path, reverse_lazy
from django.contrib.auth import views as auth_views, logout, login
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm, PasswordResetForm
from django.contrib.auth import authenticate
from .models import Login

# Create your views here.
def login_view(request):
    return render(request, 'login.html')

from django.contrib.auth.views import LoginView, PasswordResetView, PasswordResetDoneView, PasswordResetConfirmView, PasswordResetCompleteView

class CustomLoginView(LoginView):
    template_name = 'login.html'

    def form_valid(self, form):
        response = super().form_valid(form)
        if self.request.POST.get('remember'):
            self.request.session.set_expiry(1209600)  # 2 weeks
        else:
            self.request.session.set_expiry(0)  # Session expires on browser close
        return response

    def get_success_url(self):
        # Check if there's a 'next' parameter in the URL (for redirecting after login)
        next_url = self.request.GET.get('next')
        if next_url:
            return next_url
        # Default redirect to dashboard
        return '/dashboard/'

class CustomPasswordResetView(PasswordResetView):
    template_name = 'password_reset.html'
    email_template_name = 'password_reset_email.txt'  # Plain text version
    html_email_template_name = 'password_reset_email.html'  # HTML version
    subject_template_name = 'password_reset_subject.txt'
    success_url = reverse_lazy('password_reset_done')
    
    def form_valid(self, form):
        """Override to ensure proper email template rendering with HTML support"""
        opts = {
            'use_https': self.request.is_secure(),
            'token_generator': self.token_generator,
            'from_email': self.from_email,
            'email_template_name': self.email_template_name,
            'subject_template_name': self.subject_template_name,
            'request': self.request,
            'html_email_template_name': self.html_email_template_name,
            'extra_email_context': self.extra_email_context,
        }
        form.save(**opts)
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Password Reset'
        return context
    
class CustomPasswordResetDoneView(PasswordResetDoneView):
    template_name = 'password_reset_done.html'

class CustomPasswordResetConfirmView(PasswordResetConfirmView):
    template_name = 'password_reset_confirm.html'
    success_url = reverse_lazy('password_reset_complete')

class CustomPasswordResetCompleteView(PasswordResetCompleteView):
    template_name = 'password_reset_complete.html'

class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = Login
        fields = ('username', 'password1', 'password2')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Customize field labels and help text
        self.fields['username'].help_text = None
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None
        
        # Add placeholders and classes
        self.fields['username'].widget.attrs.update({
            'placeholder': 'Choose a username',
            'class': 'form-input'
        })
        self.fields['password1'].widget.attrs.update({
            'placeholder': 'Create a password',
            'class': 'form-input'
        })
        self.fields['password2'].widget.attrs.update({
            'placeholder': 'Confirm your password',
            'class': 'form-input'
        })

def register_view(request):
    if request.user.is_authenticated:
        return redirect('/dashboard/')
    
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created successfully for {username}!')
            
            # Log the user in automatically after registration
            login(request, user)
            return redirect('/dashboard/')
    else:
        form = CustomUserCreationForm()
    
    return render(request, 'register.html', {'form': form})

def custom_logout_view(request):
    """Custom logout view with session cleanup and user feedback"""
    if request.user.is_authenticated:
        username = request.user.username
        logout(request)
        messages.success(request, f'Successfully logged out. Goodbye, {username}!')
    
    return redirect('login')

