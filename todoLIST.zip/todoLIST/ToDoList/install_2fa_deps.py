#!/usr/bin/env python
"""
Install 2FA Dependencies
Run this script to install the required packages for 2FA functionality
"""

import subprocess
import sys
import os

def install_package(package):
    """Install a package using pip"""
    try:
        print(f"Installing {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"✅ {package} installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install {package}: {e}")
        return False
    except Exception as e:
        print(f"❌ Error installing {package}: {e}")
        return False

def main():
    print("🔧 Installing 2FA Dependencies")
    print("=" * 40)
    
    packages = [
        "pyotp==2.9.0",
        "qrcode[pil]==7.4.2"
    ]
    
    success_count = 0
    for package in packages:
        if install_package(package):
            success_count += 1
    
    print("\n" + "=" * 40)
    if success_count == len(packages):
        print("🎉 All dependencies installed successfully!")
        print("\nYou can now:")
        print("1. Run: python manage.py runserver")
        print("2. Go to Settings and test 2FA functionality")
    else:
        print(f"⚠️  {success_count}/{len(packages)} packages installed")
        print("Please check the errors above and try again")
    
    # Test imports
    print("\n🧪 Testing imports...")
    try:
        import pyotp
        print("✅ pyotp imported successfully")
    except ImportError:
        print("❌ pyotp import failed")
    
    try:
        import qrcode
        print("✅ qrcode imported successfully")
    except ImportError:
        print("❌ qrcode import failed")

if __name__ == "__main__":
    main()
