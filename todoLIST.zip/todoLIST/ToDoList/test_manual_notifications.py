#!/usr/bin/env python
import os
import django

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login
from TaskManager.models import Task
from Dashboard.notification_service import NotificationService

def test_manual_notifications():
    # Get the user and task
    user = Login.objects.get(username='n3thunt3r')
    task = Task.objects.get(task='Urgent Test Task - Due Soon!')

    print(f'Testing manual notification for:')
    print(f'  User: {user.username}')
    print(f'  Task: {task.task}')
    print(f'  Due: {task.end}')

    # Manual notification test
    service = NotificationService()
    print()
    print('Sending manual notifications...')

    # Test email
    try:
        email_result = service.send_email_notification(user, task, 'due')
        status = 'SUCCESS' if email_result else 'FAILED'
        print(f'Email: {status}')
    except Exception as e:
        print(f'Email: ERROR - {str(e)}')

    # Test SMS  
    try:
        sms_result = service.send_sms_notification(user, task, 'due')
        status = 'SUCCESS' if sms_result else 'FAILED'
        print(f'SMS: {status}')
    except Exception as e:
        print(f'SMS: ERROR - {str(e)}')

    # Test WhatsApp
    try:
        print('Available task attributes:', [attr for attr in dir(task) if not attr.startswith('_')])
        print(f'Task fields: task={task.task}, start={task.start}, end={task.end}, desc={task.desc}')
        whatsapp_result = service.send_whatsapp_notification(user, task, 'due')
        status = 'SUCCESS' if whatsapp_result else 'FAILED'
        print(f'WhatsApp: {status}')
    except Exception as e:
        print(f'WhatsApp: ERROR - {str(e)}')
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    test_manual_notifications()
