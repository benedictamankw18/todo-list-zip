#!/usr/bin/env python3
"""
Direct database test for WhatsApp social account
"""

import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ToDoList.settings')
django.setup()

from Login.models import Login as User
from Dashboard.models import Social

def test_whatsapp_database():
    """Test adding WhatsApp to database directly"""
    
    try:
        # Get test user
        user = User.objects.filter(username='testuser').first()
        if not user:
            print("❌ Test user 'testuser' not found")
            return
        
        # Check existing social accounts
        existing_socials = Social.objects.filter(user=user)
        print(f"📊 Existing social accounts for {user.username}:")
        for social in existing_socials:
            print(f"  - {social.name}: {social.url} ({social.icon})")
        
        # Add WhatsApp account
        whatsapp_social = Social.objects.create(
            user=user,
            name='WHATSAPP',
            url='https://wa.me/1234567890',
            icon='fab fa-whatsapp'
        )
        
        print(f"✅ WhatsApp social account created successfully!")
        print(f"   ID: {whatsapp_social.id}")
        print(f"   Name: {whatsapp_social.name}")
        print(f"   URL: {whatsapp_social.url}")
        print(f"   Icon: {whatsapp_social.icon}")
        print(f"   User: {whatsapp_social.user.username}")
        
        # Verify it was saved
        saved_whatsapp = Social.objects.filter(user=user, name='WHATSAPP').first()
        if saved_whatsapp:
            print(f"✅ WhatsApp account verified in database")
        else:
            print(f"❌ WhatsApp account not found in database")
            
        # Show all social accounts now
        all_socials = Social.objects.filter(user=user)
        print(f"\n📊 All social accounts for {user.username}:")
        for social in all_socials:
            print(f"  - {social.name}: {social.url} ({social.icon})")
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    print("🧪 Testing WhatsApp social account in database...")
    test_whatsapp_database()
